unit DM.Server;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ZConnection, ZDataset, DB;

type

  { TDMServer }

  TDMServer = class(TDataModule)
    Connection: TZConnection;
    procedure DataModuleCreate(Sender: TObject);
    procedure DataModuleDestroy(Sender: TObject);
  private
    FMsgErro: string;
    FPathDLL, FPathBanco : String;
    FCriarTabelas: Boolean;
    procedure ChecaTabelas;
  public
    procedure Desconectar;
    procedure ChecaConexao;
    function NewQuery(): TZQuery;
    function LastIDCommand(): String;
    function LastInsertedID: Integer;
    property GetMsgErro: string read FMsgErro;
  end;

var
  DMServer: TDMServer;

implementation

{$R *.lfm}

{ TDMServer }

procedure TDMServer.DataModuleCreate(Sender: TObject);
begin
  FMsgErro      := '';
  FPathBanco    := ExtractFileDir( ParamStr(0) ) + PathDelim + 'topazziorest.db';
  FPathDLL      := ExtractFileDir( ParamStr(0) ) + PathDelim + 'sqlite3.dll';
  FCriarTabelas := not FileExists( FPathBanco );

  try
    with Connection do begin
     Protocol   := 'sqlite';
     AutoCommit := True;
     Database   := FPathBanco;

     {$IFDEF WINDOWS}
        LibraryLocation := FPathDLL;
     {$ENDIF}

     Connect;
    end;

    ChecaTabelas;
  except
    on E: Exception do
       FMsgErro := E.Message;
  end;
end;

procedure TDMServer.DataModuleDestroy(Sender: TObject);
// desconecta do banco de daddos ao destruir este módulo
begin
  try
    if Connection.Connected then
       Connection.Disconnect;
  except
    on e: Exception do
      FMsgErro := e.Message;
  end;
end;

procedure TDMServer.ChecaTabelas;
begin
  if not FCriarTabelas then Exit;

  ChecaConexao;

  try
    // cria as tabelas
    Connection.ExecuteDirect('CREATE TABLE IF NOT EXISTS api (' +
                             'idapi INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ' +
                             'apiname varchar (100), ' +
                             'host_root varchar (100), ' +
                             'versao varchar (50), ' +
                             'basic_username varchar (50), ' +
                             'basic_password varchar (50), ' +
                             'token TEXT, ' +
                             'description TEXT, ' +
                             'header_texto1 TEXT, ' +
                             'header_texto2 TEXT, ' +
                             'header_texto3 TEXT, ' +
                             'footer_texto1 TEXT, ' +
                             'footer_texto2 TEXT, ' +
                             'CONSTRAINT api_unique UNIQUE (apiname, versao) ' +
                             '); ');

    Connection.ExecuteDirect('CREATE TABLE IF NOT EXISTS endpoint (' +
                             'idep INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ' +
                             'idapi INTEGER REFERENCES api (idapi) ON DELETE CASCADE NOT NULL, ' +
                             'rtgroup varchar (50) NOT NULL, ' +
                             'method varchar (15) NOT NULL, ' +
                             'route varchar (100) NOT NULL, ' +
                             'authmode varchar(50), ' +
                             'contenttype varchar (50) NOT NULL, ' +
                             'table_fields TEXT, ' +
                             'headers TEXT, ' +
                             'parameters TEXT, ' +
                             'body TEXT, ' +
                             'description TEXT, ' +
                             'response_ok_code varchar(10), ' +
                             'response_ok_type varchar(50), ' +
                             'response_ok_text TEXT, ' +
                             'response_neg_code varchar(10), ' +
                             'response_neg_type varchar(50), ' +
                             'response_neg_text TEXT, ' +
                             'CONSTRAINT route_unique UNIQUE (idapi, method, route) ' +
                             '); ');

    Connection.ExecuteDirect('CREATE INDEX IF NOT EXISTS idx_api ON api (idapi, apiname); ');
    Connection.ExecuteDirect('CREATE INDEX IF NOT EXISTS idx_endpoint ON endpoint (idep, idapi, rtgroup, route); ');
  except
  end;
end;

procedure TDMServer.Desconectar;
// desconecta do banco de dados
begin
  try
    if Connection.Connected then
       Connection.Disconnect;
  except
    on e: Exception do
      FMsgErro := e.Message;
  end;
end;

procedure TDMServer.ChecaConexao;
// se a conexão não estiver aberta, então tenta conectar no servidor/banco
begin
   FMsgErro := '';

   try
     if not Connection.Connected then Connection.Connect;
   except
    on e: Exception do
      FMsgErro := e.Message;
   end;
end;

function TDMServer.NewQuery(): TZQuery;
// retorna a instância de uma nova query
begin
  ChecaConexao;

  Result := TZQuery.Create(nil);

  if FMsgErro.IsEmpty then begin
    try
      Result.Connection := Connection;
      Result.Close;
      Result.SQL.Clear;
    except
      on e: Exception do
        FMsgErro := e.Message;
    end;
  end;
end;

function TDMServer.LastIDCommand(): String;
begin
  Result := 'select last_insert_rowid() as id; ';
end;

function TDMServer.LastInsertedID: Integer;
// retorna o último ID inserido, independente da tabela
begin
  Result := 0;

  try
    with NewQuery() do begin
      SQL.Add( LastIDCommand() );
      Open;

      if RecordCount > 0 then
         Result := FieldByName('id').AsInteger;

      Close;
    end;
  except
  end;
end;

end.


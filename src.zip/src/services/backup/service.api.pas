unit Service.Api;

// tabela de api

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, DB, SQLDB, ZDataset;

type

  { TServiceApi }

  TServiceApi = class
    private
      FBasicPassword: string;
      FBasicUsername: string;
      FFooter_Texto1: string;
      FFooter_Texto2: string;
      FHeader_Texto1: string;
      FHeader_Texto2: string;
      FHeader_Texto3: string;
      FIdApi: Integer;
      FApiName: String;
      FHostRoot: string;
      FToken: string;
      FDescription: String;
      FUrl_Logo: string;
      FVersao: string;

      sMsg, sErr: String;
    public
      constructor Create;
      destructor Destroy; override;
      property Memssagem: String read sMsg;
      property MensagemErro: String read sErr;
      property Url_Logo: string read FUrl_Logo;

      property IdApi: Integer read FIdApi; // int Primary Key
      property ApiName: String read FApiName write FApiName;  // (100) nome da api
      property HostRoot: string read FHostRoot write FHostRoot; // (TEXT) enderço http da api
      property Versao: string read FVersao write FVersao; // (50) versão da api: /api/v1
      property BasicUsername: string read FBasicUsername write FBasicUsername;
      property BasicPassword: string read FBasicPassword write FBasicPassword;
      property Token: string read FToken write FToken; // (TEXT) enderço http da api
      property Description: String read FDescription write FDescription; // (TEXT) descrição da api
      property Header_Texto1: String read FHeader_Texto1 write FHeader_Texto1; // TEXT
      property Header_Texto2: String read FHeader_Texto2 write FHeader_Texto2; // TEXT
      property Header_Texto3: String read FHeader_Texto3 write FHeader_Texto3; // TEXT
      property Footer_Texto1: String read FFooter_Texto1 write FFooter_Texto1; // TEXT
      property Footer_Texto2: String read FFooter_Texto2 write FFooter_Texto2; // TEXT

      function Salvar(AIdApi: Integer): Boolean;
      procedure SalvarToken(AIdApi: Integer; AToken: string);
      function Ler(AIdApi: Integer): Boolean;
      function Deletar(AIdApi: Integer): Boolean;
      function DatasetGridApi(APesquisa: string): TDataSource;
      function qryListApiCollection: TZQuery;
  end;

implementation

uses
  DM.Server;

constructor TServiceApi.Create;
begin
  sMsg := '';
  sErr := '';
  FUrl_Logo := 'apidoc.png';
end;

destructor TServiceApi.Destroy;
begin
  inherited Destroy;
end;

function TServiceApi.Salvar(AIdApi: Integer): Boolean;
//alva as informações do rótulo
begin
  Result := False;
  with DMServer.NewQuery() do begin
    try
      if AIdApi < 1 then begin
        SQL.Add('insert into api ');
        SQL.Add('(apiname, host_root, versao, basic_username, basic_password, token, description, ');
        SQL.Add('header_texto1, header_texto2, header_texto3, footer_texto1, footer_texto2) ');
        SQL.Add('values(:apiname, :host_root, :versao, :basic_username, :basic_password, :token, ');
        SQL.Add(':description, :header_texto1, :header_texto2, :header_texto3, :footer_texto1, :footer_texto2); ');
      end else begin
        SQL.Add('update api set ');
        SQL.Add(' apiname = :apiname, host_root = :host_root, versao = :versao, basic_username = :basic_username, ');
        SQL.Add(' basic_password = :basic_password, token = :token, description = :description, ');
        SQL.Add(' header_texto1 = :header_texto1, header_texto2 = :header_texto2, header_texto3 = :header_texto3, ');
        SQL.Add(' footer_texto1 = :footer_texto1, footer_texto2 = :footer_texto2 ');
        SQL.Add('where idapi =' +  IntToStr(AIdApi));
      end;

      ParamByName('apiname').AsString        := ApiName;
      ParamByName('host_root').AsString      := HostRoot;
      ParamByName('versao').AsString         := Versao;
      ParamByName('basic_username').AsString := BasicUsername;
      ParamByName('basic_password').AsString := BasicPassword;
      ParamByName('token').AsString          := Token;
      ParamByName('description').AsString    := Description;
      ParamByName('header_texto1').AsString  := Header_Texto1;
      ParamByName('header_texto2').AsString  := Header_Texto2;
      ParamByName('header_texto3').AsString  := Header_Texto3;
      ParamByName('footer_texto1').AsString  := Footer_Texto1;
      ParamByName('footer_texto2').AsString  := Footer_Texto2;

      ExecSQL;

      if AIdApi < 1 then begin
        FIdApi := DMServer.LastInsertedID;
        sMsg := 'API cadastrada com sucesso';
      end else begin
        FIdApi := AIdApi;
        sMsg := 'API atualizada com sucesso';
      end;

      Result := True;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

procedure TServiceApi.SalvarToken(AIdApi: Integer; AToken: string);
//salva o token gerado
begin
  with DMServer.NewQuery() do begin
    try
      SQL.Add('update api set ');
      SQL.Add('token = :token ');
      SQL.Add('where idapi = :idapi ');

      ParamByName('token').AsString  := AToken;
      ParamByName('idapi').AsInteger := AIdApi;

      ExecSQL;

      sMsg := 'Token salvo com sucesso';
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

function TServiceApi.Ler(AIdApi: Integer):Boolean;
//obtém dados do rótulo indicado
begin
  Result := False;
  with DMServer.NewQuery() do begin
    try
      SQL.Add('select ');
      SQL.Add('  apiname, host_root, versao, basic_username, basic_password, token, description, ');
      SQL.Add('  header_texto1, header_texto2, header_texto3, footer_texto1, footer_texto2 ');
      SQL.Add('from api ');
      SQL.Add('where idapi = ' + IntToStr(AIdApi));
      Open;

      if RecordCount > 0 then begin
         FIdApi        := AIdApi;
         ApiName       := FieldByName('apiname').AsString;
         HostRoot      := FieldByName('host_root').AsString;
         Versao        := FieldByName('versao').AsString;
         BasicUsername := FieldByName('basic_username').AsString;
         BasicPassword := FieldByName('basic_password').AsString;
         Token         := FieldByName('token').AsString;
         Description   := FieldByName('description').AsString;
         Header_Texto1 := FieldByName('header_texto1').AsString;
         Header_Texto2 := FieldByName('header_texto2').AsString;
         Header_Texto3 := FieldByName('header_texto3').AsString;
         Footer_Texto1 := FieldByName('footer_texto1').AsString;
         Footer_Texto2 := FieldByName('footer_texto2').AsString;

         Result := True;
      end else
        sErr := 'API não encontrada.';

      Close;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

function TServiceApi.Deletar(AIdApi: Integer): Boolean;
// Deleta a API e os endpoints em cascata
begin
  Result := False;
  with DMServer.NewQuery() do begin
    try
      SQL.Add('delete from api where idapi = ' + IntToStr(AIdApi));
      ExecSQL;
      sMsg := 'API deletada com sucesso.';
      Result := True;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

function TServiceApi.DatasetGridApi(APesquisa: string): TDataSource;
var
  q: TZQuery;
begin
  Result    := TDataSource.Create(nil);

  with DMServer.NewQuery() do begin
    try
      q := DMServer.NewQuery();

      q.SQL.Add('select ');
      q.SQL.Add('a.idapi, a.apiname, a.host_root, a.versao, ');
      q.SQL.Add('(select coalesce(count(e.idep),0) from endpoint e where e.idapi = a.idapi) as qde_rotas ');
      q.SQL.Add('from api a ');

      if Trim(APesquisa) <> '' then begin
         q.SQL.Add('where concat(a.apiname, a.host_root) like :pesquisa ');
         q.ParamByName('pesquisa').Asstring := '%' + APesquisa + '%';
      end;

      q.SQL.Add('order by a.apiname asc ');

      q.Open;

      Result.DataSet := q;
      //Fechar somente lá no cliente/destino
      //Close;
    except
      on ex: Exception do begin
        sErr := ex.Message;
        q.Free;
      end;
    end;
  end;
end;

function TServiceApi.qryListApiCollection: TZQuery;
// coleção das APIs e suas rotas
begin
  Result := DMServer.NewQuery();

  with Result do begin
    try
      SQL.Add('select ');
      SQL.Add(' a.idapi, a.apiname as api_name, a.host_root as api_host_root, a.versao, ');
      SQL.Add(' a.basic_username, a.basic_password, a.token, a.description as api_description, ');
      SQL.Add(' e.idep, e.rtgroup, e.method, e.route, e.authmode, e.contenttype, ');
      SQL.Add(' e.parameters, e.body, e.description ');
      SQL.Add('from api a ');
      SQL.Add('inner join endpoint e on e.idapi = a.idapi ');
      SQL.Add('order by a.apiname, e.rtgroup, e.method, e.route ');

      Open;

      //Fechar somente lá no cliente/destino
      //Close;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

end.


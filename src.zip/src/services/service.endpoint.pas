unit Service.Endpoint;

// tabela de rotas/endpoints

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, DB, SQLDB, ZDataset;

type

  { TServiceEndpoint }

  TServiceEndpoint = class
    private
      FIdAPI: Integer;
      FApiName: string;
      FApiHost: string;
      FApiVersao: string;
      FApiDescripion: string;
      FApiFooter_Texto1: String;
      FApiFooter_Texto2: String;
      FApiHeader_Texto1: String;
      FApiHeader_Texto2: String;
      FApiHeader_Texto3: String;
      FBasicUsername: string;
      FBasicPassword: string;
      FApiToken: string;
      FApiBasicPassword: string;
      FApiBasicUsername: string;

      FIdEndpoint: Integer;
      FGroup: String;
      FMethod: String;
      FPrefix: string;
      FRoute: string;
      FAuthMode: string;
      FContentType: String;
      FTableFields: string;
      FHeaders: string;
      FParameters: string;
      FBody: String;
      FDescription: String;
      FResponseOKCode: string;
      FResponseOKType: string;
      FResponseOKText: string;
      FResponseNegCode: string;
      FResponseNegType: string;
      FResponseNegText: string;

      sMsg, sErr: String;
    public
      constructor Create(AIdApi: Integer);
      destructor Destroy; override;
      property Memssagem: String read sMsg;
      property MensagemErro: String read sErr;

      property IdApi: Integer read FIdAPI; //int Primary Key
      property ApiName: string read FApiName;
      property ApiHost: string read FApiHost;
      property ApiVersao: string read FApiVersao;
      property ApiDescripion: string read FApiDescripion;
      property ApiHeader_Texto1: String read FApiHeader_Texto1; // TEXT
      property ApiHeader_Texto2: String read FApiHeader_Texto2; // TEXT
      property ApiHeader_Texto3: String read FApiHeader_Texto3; // TEXT
      property ApiFooter_Texto1: String read FApiFooter_Texto1; // TEXT
      property ApiFooter_Texto2: String read FApiFooter_Texto2; // TEXT
      property ApiBasicUsername: string read FApiBasicUsername;
      property ApiBasicPassword: string read FApiBasicPassword;
      property ApiToken: string read FApiToken;

      property IdEndpoint: Integer read FIdEndpoint; //int Primary Key
      property Group: String read FGroup write FGroup; // 50 varchar
      property Method: String read FMethod write FMethod;    //15 / varchar
      property Prefix: string read FPrefix write FPrefix; // 30 / varchar
      property Route: string read FRoute write FRoute; //100 / varchar
      property AuthMode: string read FAuthMode write FAuthMode; //50 / varchar
      property ContentType: String read FContentType write FContentType; //15 varchar
      property TableFields: string read FTableFields write FTableFields;
      property Headers: string read FHeaders write FHeaders;
      property Parameters: string read FParameters write FParameters; //TEXT
      property Body: String read FBody write FBody; //TEXT
      property Description: String read FDescription write FDescription; //TEXT
      property ResponseOKCode: string read FResponseOKCode write FResponseOKCode; //50
      property ResponseOKType: string read FResponseOKType write FResponseOKType; //50 {contenttype}
      property ResponseOKText: string read FResponseOKText write FResponseOKText; //TEXT
      property ResponseNegCode: string read FResponseNegCode write FResponseNegCode; //50
      property ResponseNegType: string read FResponseNegType write FResponseNegType; //50 {contenttype}
      property ResponseNegText: string read FResponseNegText write FResponseNegText; //TEXT

      function Salvar(AIdEndPoint: Integer): Boolean;
      function Ler(AIdEndPoint: Integer): Boolean;
      function Deletar(AIdEndPoint: Integer): Boolean;
      function qryEndPoints(AIdApi: Integer; AGroupRota: String): TZQuery;
      function qryGrupoRotas(AIdApi: Integer): TZQuery;
      function GetFieldsFromPost(AIdApi: Integer; ARouteGroup: string): string;
      procedure SalvarResponseOK(AIdEndPoint: Integer; ACode, AContentType, AResponse: string);
      procedure SalvarResponseNeg(AIdEndPoint: Integer; ACode, AContentType, AResponse: string);
  end;

implementation

uses
  DM.Server;

constructor TServiceEndpoint.Create(AIdApi: Integer);
begin
  FIdAPI := AIdApi;
  sMsg := '';
  sErr := '';
  if AIdApi < 1 then sErr := 'ID da API não foi informado';
end;

destructor TServiceEndpoint.Destroy;
begin
  inherited Destroy;
end;

function TServiceEndpoint.Salvar(AIdEndPoint: Integer): Boolean;
//alva as informações do rótulo
begin
  Result := False;
  if FIdAPI < 1 then Exit;

  with DMServer.NewQuery() do begin
    try
      if AIdEndPoint < 1 then begin
        SQL.Add('INSERT INTO endpoint ');
        SQL.Add(' (idapi, rtgroup, method, prefix, route, authmode, contenttype, ');
        SQL.Add(' table_fields, headers, parameters, body, description) ');
        SQL.Add('VALUES(:idapi, :rtgroup, :method, :prefix, :route, :authmode, :contenttype, ');
        SQL.Add(':table_fields, :headers, :parameters, :body, :description); ');
      end else begin
        SQL.Add('UPDATE endpoint SET ');
        SQL.Add(' idapi = :idapi, rtgroup = :rtgroup, method = :method, prefix = :prefix, ');
        SQL.Add(' route = :route, authmode = :authmode, contenttype = :contenttype, ');
        SQL.Add(' table_fields = :table_fields, headers = :headers, parameters = :parameters, ');
        SQL.Add(' body = :body, description = :description ');
        SQL.Add('WHERE idep = ' +  IntToStr(AIdEndPoint));
      end;

      ParamByName('idapi').AsInteger         := FIdAPI;
      ParamByName('rtgroup').AsString        := Group;
      ParamByName('method').AsString         := Method;
      ParamByName('prefix').AsString         := Prefix;
      ParamByName('route').AsString          := Route;
      ParamByName('authmode').AsString       := AuthMode;
      ParamByName('contenttype').AsString    := ContentType;
      ParamByName('table_fields').AsString   := TableFields;
      ParamByName('headers').AsString        := Headers;
      ParamByName('parameters').AsString     := Parameters;
      ParamByName('body').AsString           := Body;
      ParamByName('description').AsString    := Description;

      ExecSQL;

      if AIdEndPoint < 1 then begin
        FIdEndPoint := DMServer.LastInsertedID;
        sMsg := 'Novo EndPoint criado com sucesso.';
      end else begin
        sMsg := 'EndPoint atualizado com sucesso.';
        FIdEndpoint := AIdEndPoint;
      end;

      Result := True;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;

    Free;
  end;
end;

function TServiceEndpoint.Ler(AIdEndPoint: Integer): Boolean;
//obtém dados do rótulo indicado
begin
  Result := False;
  with DMServer.NewQuery() do begin
    try
      SQL.Add('SELECT ');
      SQL.Add('  a.apiname AS api_name, a.host_root AS api_host_root, a.versao, a.basic_username, ');
      SQL.Add('  a.basic_password, a.token, a.description AS api_description, ');
      SQL.Add('  a.header_texto1, a.header_texto2, a.header_texto3, a.footer_texto1, a.footer_texto2, ');
      SQL.Add('  e.idapi, e.rtgroup, e.method, e.prefix, e.route, e.authmode, e.contenttype, ');
      SQL.Add('  e.table_fields, e.headers, e.parameters, e.body, e.description, ');
      SQL.Add('  e.response_ok_code, e.response_ok_type, e.response_ok_text, ');
      SQL.Add('  e.response_neg_code, e.response_neg_type, e.response_neg_text ');
      SQL.Add('FROM endpoint e ');
      SQL.Add('INNER JOIN api a ON a.idapi = e.idapi ');
      SQL.Add('WHERE e.idep = :idep ');

      ParamByName('idep').AsInteger := AIdEndPoint;

      Open;

      if RecordCount > 0 then begin
         FIdAPI            := FieldByName('idapi').AsInteger;
         FApiName          := FieldByName('api_name').AsString;
         FApiHost          := FieldByName('api_host_root').AsString;
         FApiVersao        := FieldByName('versao').AsString;
         FApiDescripion    := FieldByName('api_description').AsString;
         FApiHeader_Texto1 := FieldByName('header_texto1').AsString;
         FApiHeader_Texto2 := FieldByName('header_texto2').AsString;
         FApiHeader_Texto3 := FieldByName('header_texto3').AsString;
         FApiFooter_Texto1 := FieldByName('footer_texto1').AsString;
         FApiFooter_Texto2 := FieldByName('footer_texto2').AsString;
         FApiBasicUsername := FieldByName('basic_username').AsString;
         FApiBasicPassword := FieldByName('basic_password').AsString;
         FApiToken         := FieldByName('token').AsString;

         //endpoint
         FIdEndpoint  := AIdEndPoint;
         Group        := FieldByName('rtgroup').AsString;
         Method       := FieldByName('method').AsString;
         Prefix       := FieldByName('prefix').AsString;
         Route        := FieldByName('route').AsString;
         AuthMode     := FieldByName('authmode').AsString;
         ContentType  := FieldByName('contenttype').AsString;
         TableFields  := FieldByName('table_fields').AsString;
         Parameters   := FieldByName('parameters').AsString;
         Headers      := FieldByName('headers').AsString;
         Body         := FieldByName('body').AsString;
         Description  := FieldByName('description').AsString;
         ResponseOKCode  := FieldByName('response_ok_code').AsString;
         ResponseOKType  := FieldByName('response_ok_type').AsString;
         ResponseOKText  := FieldByName('response_ok_text').AsString;
         ResponseNegCode := FieldByName('response_neg_code').AsString;
         ResponseNegType := FieldByName('response_neg_type').AsString;
         ResponseNegText := FieldByName('response_neg_text').AsString;

         Result := True;
      end else
        sErr := 'EndPoint não encontrado.';

      Close;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;

    Free;
  end;
end;

function TServiceEndpoint.Deletar(AIdEndPoint: Integer): Boolean;
//Deleta o rótulo
begin
  Result := False;
  with DMServer.NewQuery() do begin
    try
      SQL.Add('DELETE FROM endpoint WHERE idep = ' + IntToStr(AIdEndPoint));
      ExecSQL;
      sMsg := 'EndPoint deletado com sucesso.';
      Result := True;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;

    Free;
  end;
end;

function TServiceEndpoint.qryEndPoints(AIdApi: Integer; AGroupRota: String): TZQuery;
// Retorna um dataset dos endpoints do grupo de rotas
begin
  Result := DMServer.NewQuery();

  with Result do begin
    try
      SQL.Add('SELECT ');
      SQL.Add('  a.idapi, a.apiname AS api_name, a.host_root AS api_host_root, a.versao, ');
      SQL.Add('  a.basic_username, a.basic_password, a.token, a.description AS api_description, ');
      SQL.Add('  e.idep, e.rtgroup, e.method, e.prefix, e.route, e.authmode, e.contenttype, ');
      SQL.Add('  e.table_fields, e.headers, e.parameters, e.body, e.description, ');
      SQL.Add('  e.response_ok_code, e.response_ok_type, e.response_ok_text, ');
      SQL.Add('  e.response_neg_code, e.response_neg_type, e.response_neg_text ');
      SQL.Add('FROM ');
      SQL.Add('  endpoint e ');
      SQL.Add('  INNER JOIN api a ON a.idapi = e.idapi ');
      SQL.Add('WHERE ');
      SQL.Add('  a.idapi = :idapi AND e.rtgroup = :rtgroup ');
      SQL.Add('order by e.rtgroup, e.method, e.route ');

      ParamByName('idapi').AsInteger  := AIdApi;
      ParamByName('rtgroup').AsString := AGroupRota;

      Open;

      //Fechar somente lá no cliente/destino
      //Close;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

function TServiceEndpoint.qryGrupoRotas(AIdApi: Integer): TZQuery;
// lista os grupos de rotas
begin
  Result := DMServer.NewQuery();

  with Result do begin
    try
      SQL.Add('SELECT ');
      SQL.Add('  ROW_NUMBER() OVER (ORDER BY g.rtgroup ASC) idgroup, g.rtgroup ');
      SQL.Add('FROM (');
      SQL.Add('  SELECT ');
      SQL.Add('    DISTINCT rtgroup ');
      SQL.Add('  FROM ');
      SQL.Add('    endpoint ');
      SQL.Add('  WHERE ');
      SQL.Add('    idapi = :idapi ');
      SQL.Add(') g ');

      ParamByName('idapi').AsInteger := AIdApi;

      Open;

      //Fechar somente lá no cliente/destino
      //Close;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

function TServiceEndpoint.GetFieldsFromPost(AIdApi: Integer; ARouteGroup: string): string;
// retorna o string json dos campos da tabela
begin
  Result := '[]';

  with DMServer.NewQuery() do begin
    try
      SQL.Add('SELECT ');
      SQL.Add('  table_fields ');
      SQL.Add('FROM ');
      SQL.Add('  endpoint ');
      SQL.Add('WHERE ');
      SQL.Add('  idapi = :idapi ');
      SQL.Add('  AND LOWER(rtgroup) = :rtgroup ');
      SQL.Add('  AND NOT table_fields IN('''',''[]'') ');
      SQL.Add('  AND method IN(''POST'',''PUT'') ');
      SQL.Add('ORDER BY ');
      SQL.Add('  method ASC ');
      SQL.Add('LIMIT 1; ');

      ParamByName('idapi').AsInteger  := AIdApi;
      ParamByName('rtgroup').AsString := LowerCase(ARouteGroup);

      Open;

      if not EOF then
        Result := FieldByName('table_fields').AsString;

      Close;
    except
      on ex: Exception do
        sErr := ex.Message;
    end;

    Free;
  end;
end;

procedure TServiceEndpoint.SalvarResponseOK(AIdEndPoint: Integer; ACode, AContentType, AResponse: string);
// salva o response positivo
begin
  with DMServer.NewQuery() do begin
    try
      SQL.Add('UPDATE endpoint SET ');
      SQL.Add(' response_ok_code = :response_ok_code, ');
      SQL.Add(' response_ok_type = :response_ok_type, '); // 200-ok, 401-Unauthorized
      SQL.Add(' response_ok_text = :response_ok_text ');
      SQL.Add('WHERE idep = :idep ');

      ParamByName('response_ok_code').AsString := ACode;
      ParamByName('response_ok_type').AsString := AContentType;
      ParamByName('response_ok_text').AsString := AResponse;
      ParamByName('idep').AsInteger := AIdEndPoint;

      ExecSQL;

      sMsg := 'Response postivio salvo com sucesso';
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

procedure TServiceEndpoint.SalvarResponseNeg(AIdEndPoint: Integer; ACode, AContentType, AResponse: string);
// salva o response negativo
begin
  with DMServer.NewQuery() do begin
    try
      SQL.Add('UPDATE endpoint SET ');
      SQL.Add(' response_neg_code = :response_neg_code, ');
      SQL.Add(' response_neg_type = :response_neg_type, '); // 200-ok, 401-Unauthorized
      SQL.Add(' response_neg_text = :response_neg_text ');
      SQL.Add('WHERE idep = :idep ');

      ParamByName('response_neg_code').AsString := ACode;
      ParamByName('response_neg_type').AsString := AContentType;
      ParamByName('response_neg_text').AsString := AResponse;
      ParamByName('idep').AsInteger := AIdEndPoint;

      ExecSQL;

      sMsg := 'Response negativo salvo com sucesso';
    except
      on ex: Exception do
        sErr := ex.Message;
    end;
  end;
end;

end.


unit View.Api;

// controle de Api

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Buttons, DBGridPlus, DBGrids, DB;

type

  { TfrmViewApi }

  TfrmViewApi = class(TForm)
    btnApiNovo: TSpeedButton;
    btnApiDeletar: TSpeedButton;
    btnApiRetornar: TSpeedButton;
    btnApiSalvar: TSpeedButton;
    dbgPesquisa: TDBGridPlus;
    edtApiPesquisa: TEdit;
    edtApiName: TEdit;
    edtApiId: TEdit;
    edtApiHost: TEdit;
    edtApiDescricao: TMemo;
    lblApiGridAtualizar: TLabel;
    lblApiGridTitulo: TLabel;
    lblApiToken: TLabel;
    lblApiDescricao: TLabel;
    lblApiHost2: TLabel;
    lblApiName: TLabel;
    lblApiHost: TLabel;
    lblHeaderText1: TLabel;
    lblHeaderText2: TLabel;
    edtApiToken: TMemo;
    panHeader: TPanel;
    procedure btnApiDeletarClick(Sender: TObject);
    procedure btnApiNovoClick(Sender: TObject);
    procedure btnApiRetornarClick(Sender: TObject);
    procedure btnApiSalvarClick(Sender: TObject);
    procedure dbgPesquisaCellClick(Column: TColumn);
    procedure edtApiHostExit(Sender: TObject);
    procedure edtApiPesquisaChange(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormShow(Sender: TObject);
    procedure lblApiGridAtualizarClick(Sender: TObject);
  private
    FApi_Deletou: Boolean;
    Fapi_description: string;
    FApi_Host: string;
    FApi_Id: Integer;
    FApi_Name: string;
    FApi_Token: string;
    procedure Api_CarregaGrid;
    procedure Api_Ler(AIdApi: Integer);
    procedure Api_Limpar;
    procedure Api_Salvar(AIdApi: Integer);
    procedure Api_Deletar(AIdApi: Integer);
    function AjustaHost(s: string): string;
  public
    property Api_Id: Integer read FApi_Id;
    property Api_Name: string read FApi_Name;
    property Api_Host: string read FApi_Host;
    property Api_Token: string read FApi_Token;
    property Api_Description: string read Fapi_description;
    property Api_Deletou: Boolean read FApi_Deletou;
  end;

var
  frmViewApi: TfrmViewApi;

implementation

uses
  Service.Api;

{$R *.lfm}

{ TfrmViewApi }

procedure TfrmViewApi.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  if (dbgPesquisa.DataSource <> nil) and (dbgPesquisa.DataSource.DataSet <> nil) then
    dbgPesquisa.DataSource.DataSet.Close;
end;

procedure TfrmViewApi.FormShow(Sender: TObject);
begin
  FApi_Id := 0;
  FApi_Name := '';
  FApi_Host := '';
  FApi_Token := '';
  Fapi_Description := '';
  FApi_Deletou := False;

  Api_CarregaGrid;
end;

procedure TfrmViewApi.lblApiGridAtualizarClick(Sender: TObject);
begin
  Api_CarregaGrid;
end;

procedure TfrmViewApi.dbgPesquisaCellClick(Column: TColumn);
begin
  if (dbgPesquisa.DataSource <> nil) and (dbgPesquisa.DataSource.DataSet.RecordCount > 0) then
    Api_Ler( dbgPesquisa.DataSource.DataSet.FieldByName('idapi').AsInteger );
end;

procedure TfrmViewApi.edtApiHostExit(Sender: TObject);
begin
  //if RightStr(edtApiHost.Text, 1) = '/' then
  //  edtApiHost.Text := LeftStr(edtApiHost.Text, Length(edtApiHost.Text)-1);
  edtApiHost.Text := AjustaHost(edtApiHost.Text);
end;

procedure TfrmViewApi.edtApiPesquisaChange(Sender: TObject);
begin
  Api_CarregaGrid;
end;

procedure TfrmViewApi.btnApiSalvarClick(Sender: TObject);
begin
  Api_Salvar(StrToIntDef(edtApiId.Text, 0));
end;

procedure TfrmViewApi.btnApiDeletarClick(Sender: TObject);
begin
  Api_Deletar(StrToIntDef(edtApiId.Text, 0));
end;

procedure TfrmViewApi.btnApiNovoClick(Sender: TObject);
begin
  Api_Limpar;
  edtApiName.SetFocus;
end;

procedure TfrmViewApi.btnApiRetornarClick(Sender: TObject);
begin
  if StrToIntDef(edtApiId.Text, 0) > 0 then begin
    FApi_Id := StrToIntDef(edtApiId.Text, 0);
    FApi_Name := Trim(edtApiName.Text);
    FApi_Host := Trim(edtApiHost.Text);
    FApi_Token := Trim(edtApiToken.Text);
    Fapi_Description := Trim(edtApiDescricao.Text);
    Close;
  end else
    ShowMessage('Selecione uma API na lista');
end;

procedure TfrmViewApi.Api_CarregaGrid;
begin
  dbgPesquisa.ClearRows;
  with TServiceApi.Create do begin
    dbgPesquisa.DataSource := DatasetGridApi(edtApiPesquisa.Text);
    Free;
  end;
end;

procedure TfrmViewApi.Api_Ler(AIdApi: Integer);
var
  p: TServiceApi;
begin
  Api_Limpar;

  p := TServiceApi.Create;

  if p.Ler( AIdApi ) then begin
    edtApiId.Text := p.IdApi.ToString;
    edtApiName.Text := p.ApiName;
    edtApiHost.Text := p.HostRoot;
    edtApiToken.Text := p.Token;
    edtApiDescricao.Text := p.Description;
  end else
    ShowMessage( p.MensagemErro );

  p.Free;
end;

procedure TfrmViewApi.Api_Salvar(AIdApi: Integer);
var
  p: TServiceApi;
begin
  if (Trim(edtApiName.Text)='') or (Trim(edtApiHost.Text)='') then begin
    ShowMessage('Nome da Api e Host são obrigatórios');
    exit;
  end;

  p := TServiceApi.Create;

  p.ApiName := Trim(edtApiName.Text);
  p.HostRoot := AjustaHost(Trim(edtApiHost.Text));
  p.Token := Trim(edtApiToken.Text);
  p.Description := Trim(edtApiDescricao.Text);

  if p.Salvar( AIdApi ) then begin
    Api_CarregaGrid;
    ShowMessage( p.Memssagem );
  end
  else
    ShowMessage( p.MensagemErro );

  p.Free;
end;

procedure TfrmViewApi.Api_Deletar(AIdApi: Integer);
var
  p: TServiceApi;
begin
  //mrNo, mrYes, mrCancel;
  if QuestionDlg('Atenção','Deseja Deletar esta API/Rotas ?', mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') <> mrYes then
    Exit;

  p := TServiceApi.Create;

  if p.Deletar( AIdApi ) then begin
    FApi_Deletou := True;
    Api_Limpar;
    Api_CarregaGrid;
    ShowMessage( p.Memssagem );
  end else
    ShowMessage( p.MensagemErro );

  p.Free;
end;

function TfrmViewApi.AjustaHost(s: string): string;
begin
  while RightStr(s, 1) = '/' do
    s := LeftStr(s, Length(s)-1);

  Result := s;
end;

procedure TfrmViewApi.Api_Limpar;
begin
  edtApiId.Text := '0';
  edtApiName.Clear;
  edtApiHost.Clear;
  edtApiToken.Clear;
  edtApiDescricao.Clear;
end;

end.


unit View.Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  ComCtrls, Buttons, ValEdit, Grids, DividerBevel, Types, Util.EditInterpose;

type

  { TApiInfo }

  TApiInfo = class
    private
      FApiID: Integer;
      FApiName: String;
      FApiHost: String;
      FApiVersao: String;
    public
      constructor Create(AApiID: Integer; AApiName, AApiHost, AApiVersao: String);
      property ApiID: Integer read FApiID write FApiID;
      property ApiName: String read FAPIName write FAPIName;
      property ApiHost: String read FApiHost write FApiHost;
      property ApiVersao: String read FApiVersao write FApiVersao;
  end;

  { TGroupInfo }

  TGroupInfo = class
    private
      FApiInfo: TApiInfo;
      FRouteGroup: String;
    public
      constructor Create(AApiInfo: TApiInfo; ARouteGroup: String);
      property ApiInfo: TApiInfo read FApiInfo write FApiInfo;
      property RouteGroup: String read FRouteGroup write FRouteGroup;
  end;

  { TRouteInfo }

  TRouteInfo = class
  private
    FApiInfo: TApiInfo;
    FRouteID: Integer;
    FRouteGroup: String;
    FRouteMethod: String;
    FRoutePath: String;
  public
    constructor Create(AApiID: Integer; AApiName, AApiHost, AApiVersao: String;
                       ARouteID: Integer; ARouteGroup, ARouteMethod, ARoutePath: string);

    property ApiInfo: TApiInfo read FApiInfo write FApiInfo;

    property RouteID: Integer read FRouteID write FRouteID;
    property RouteGroup: String read FRouteGroup write FRouteGroup;
    property RouteMethod: String read FRouteMethod write FRouteMethod;
    property RoutePath: String read FRoutePath write FRoutePath;
  end;

  { TfrmViewMain }

  TfrmViewMain = class(TForm)
    btnParam_Adicionar: TSpeedButton;
    btnParam_Deletar: TSpeedButton;
    btnParam_Limpar: TSpeedButton;
    btnGerarDoc: TSpeedButton;
    btnFields_Deletar: TSpeedButton;
    btnFields_Limpar: TSpeedButton;
    btnNovaApi: TSpeedButton;
    btnDeletarApi: TSpeedButton;
    btnNovaRota: TSpeedButton;
    btnDeletarRota: TSpeedButton;
    btnFields_Adicionar: TSpeedButton;
    cboFields_Type: TComboBox;
    cboParam_Type: TComboBox;
    cboReqContentType: TComboBox;
    cboReqMethods: TComboBox;
    cboReqAuthentication: TComboBox;
    chkFields_Requerid: TCheckBox;
    DividerBevel1: TDividerBevel;
    DividerBevel2: TDividerBevel;
    edtApiHeader1: TEdit;
    edtApiHeader2: TEdit;
    edtApiHeader3: TEdit;
    edtApiFooter1: TEdit;
    edtApiFooter2: TEdit;
    edtApiVersao: TEdit;
    edtReqPrefixo: TEdit;
    edtParam_Descricao: TEdit;
    edtFields_Name: TEdit;
    edtAuthUsername: TEdit;
    edtAuthToken: TMemo;
    edtAuthPassword: TEdit;
    edtFields_Descricao: TEdit;
    edtFields_MaxLength: TEdit;
    edtParam_Name: TEdit;
    edtReqDescricao: TMemo;
    edtReqGrupo: TEdit;
    edtApiHost: TEdit;
    edtApiName: TEdit;
    edtResHeaders: TMemo;
    edtReqHostPath: TEdit;
    edtResBody: TMemo;
    edtApiDescricao: TMemo;
    imgLogoDoc: TImage;
    imgRouteAuth: TImage;
    imgTreeView: TImageList;
    imgHeaderLogo: TImage;
    imgMenuItens: TImageList;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    lblReqPrefixo: TLabel;
    lblBodyAllFields: TLabel;
    lblTopHost: TLabel;
    lblApiHeader1: TLabel;
    lblApiHeader2: TLabel;
    lblApiHeader3: TLabel;
    lblApiFooter1: TLabel;
    lblApiFooter2: TLabel;
    lblHeaderImportarAPI: TLabel;
    lblReqTokenExpirou: TLabel;
    lblVersao1: TLabel;
    lblVersao2: TLabel;
    lblParam_Type: TLabel;
    lblParam_description: TLabel;
    lblParam_Name: TLabel;
    lblResEndPoint: TLabel;
    lblAuthBasic: TLabel;
    lblApiTokenValidade: TLabel;
    lblAuthBasic1: TLabel;
    lblAuthPassword: TLabel;
    lblAutor1: TLabel;
    lblHeaderResize: TLabel;
    lblHeaderRecarregar: TLabel;
    lblAutor: TLabel;
    lblApiNome: TLabel;
    lblApiHost: TLabel;
    lblApiDescricao: TLabel;
    lblMethod4: TLabel;
    lblAuthUsername: TLabel;
    lblMethod5: TLabel;
    lblMethod6: TLabel;
    lblMethod7: TLabel;
    lblMethod8: TLabel;
    lblApiVersao: TLabel;
    lblReqDescricao: TLabel;
    lblReqMetodo1: TLabel;
    lblReqRota: TLabel;
    lblReqRota1: TLabel;
    lblResStatusCode: TLabel;
    lblContentType: TLabel;
    lblContentType1: TLabel;
    lblHeaderText1: TLabel;
    lblHeaderText2: TLabel;
    lblReqMetodo: TLabel;
    lblRequest: TLabel;
    lblResponse: TLabel;
    edtReqBody: TMemo;
    panRequestButtons: TPanel;
    pgRequest: TPageControl;
    panArea: TPanel;
    panBottom: TPanel;
    panHeader: TPanel;
    panRequest: TPanel;
    panResponse: TPanel;
    pgResponse: TPageControl;
    btnEnviarRequisicao: TSpeedButton;
    SaveDialog1: TSaveDialog;
    sgFields: TStringGrid;
    sgParams: TStringGrid;
    tsparameters: TTabSheet;
    tsReqFields: TTabSheet;
    tsAuthentication: TTabSheet;
    tsApi: TTabSheet;
    tsBody: TTabSheet;
    tsRequest: TTabSheet;
    tsReqHeaders: TTabSheet;
    tvCollections: TTreeView;
    tsHeaders: TTabSheet;
    reqValueListEditor: TValueListEditor;
    procedure ButtonMouseEnter(Sender: TObject);
    procedure ButtonMouseLeave(Sender: TObject);
    procedure btnGerarDocClick(Sender: TObject);
    procedure btnDeletarApiClick(Sender: TObject);
    procedure btnFields_AdicionarClick(Sender: TObject);
    procedure btnFields_DeletarClick(Sender: TObject);
    procedure btnFields_LimparClick(Sender: TObject);
    procedure btnNovaApiClick(Sender: TObject);
    procedure btnDeletarRotaClick(Sender: TObject);
    procedure btnNovaRotaClick(Sender: TObject);
    procedure btnEnviarRequisicaoClick(Sender: TObject);
    procedure btnParam_AdicionarClick(Sender: TObject);
    procedure btnParam_DeletarClick(Sender: TObject);
    procedure btnParam_LimparClick(Sender: TObject);
    procedure cboReqAuthenticationChange(Sender: TObject);
    procedure cboReqMethodsChange(Sender: TObject);
    procedure edtApiHostExit(Sender: TObject);
    procedure edtApiVersaoExit(Sender: TObject);
    procedure edtReqBodyEnter(Sender: TObject);
    procedure edtReqGrupoExit(Sender: TObject);
    procedure edtReqHostPathExit(Sender: TObject);
    procedure edtReqPrefixoExit(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormDropFiles(Sender: TObject; const FileNames: array of string);
    procedure FormShow(Sender: TObject);
    procedure lblBodyAllFieldsClick(Sender: TObject);
    procedure lblHeaderImportarAPIClick(Sender: TObject);
    procedure lblHeaderRecarregarClick(Sender: TObject);
    procedure lblHeaderResizeClick(Sender: TObject);
    procedure reqValueListEditorValidateEntry(Sender: TObject; aCol, aRow: Integer; const OldValue: string; var NewValue: String);
    procedure sgFieldsClick(Sender: TObject);
    procedure sgFieldsDrawCell(Sender: TObject; aCol, aRow: Integer; aRect: TRect; aState: TGridDrawState);
    procedure sgParamsClick(Sender: TObject);
    procedure sgParamsDrawCell(Sender: TObject; aCol, aRow: Integer; aRect: TRect; aState: TGridDrawState);
    procedure TabEnter(Sender: TObject);
    procedure TabLeave(Sender: TObject);
    procedure tvCollectionsAdvancedCustomDrawItem(Sender: TCustomTreeView;
      Node: TTreeNode; State: TCustomDrawState; Stage: TCustomDrawStage;
      var PaintImages, DefaultDraw: Boolean);
    procedure tvCollectionsClick(Sender: TObject);
  private
    FTokenExpireAt, FDefaultExpiration: Int64;
    FApiId: Integer;
    FRouteId: Integer;
    FFieldRow: Integer;
    FParamRow: Integer;
    procedure AddRoute(ARouteInfo: TRouteInfo; ASelectThis: Boolean = False);
    procedure AuthenticationChanged;
    function BodyFromFields(ADados: string; ABreakLine: Boolean): string;
    function CleanURI(const AURI: String): String;
    procedure ClearTree;
    procedure DeleteRoute;
    function ExtractFileNameFromDisposition(const ADisposition: string): string;
    function FieldsAdd(AName, AType, ASize, ADescription: string; ARequered: Boolean): Boolean;
    procedure FieldsFromJson(AstrJson: string);
    function FieldsToJson(): string;
    function FindRouteNode(ARouteInfo: TRouteInfo): TTreeNode;
    function FormatHost(AHost, AVersao, APath: string): string;
    procedure FormatJsonFromResponseBody(AContent: string);
    function GetResponseBody(AData: string; ACode: Integer; AContentType, ACodeText: string): string;
    function GetTokenExpiration(AToken: string): Int64;
    procedure ImportarAPI(APathJson: string);
    function KeyExists(VLE: TValueListEditor; const AKey: string; IgnoreRow: Integer = - 1): Boolean;
    procedure LimparCamposParams;
    function MatchRoute(ARouteOne, ARouteTwo: string): boolean;
    procedure MethodChanged;
    function Hash_Password(const APassword, AUsername: String; AIterations: Integer = 50): String;
    function ParamsAdd(AName, AType, ADescription: string): Boolean;
    procedure ParamsFromJson(AstrJson: string);
    function ParamsToJson(): string;
    procedure PegaTodosOsCampos(ABreakLine: Boolean);
    procedure RenameCollection(const AOldName, ANewName: string);
    function RouteExists(ARouteInfo: TRouteInfo; AUpdate: Boolean = False): Boolean;
    function SimplifyRoute(const ARoute: String): String;
    function SplitParam(const S: string): TStringArray;
    function TreeToJSON(Tree: TTreeView): string;
    procedure UpdateSelectedRoute(const ANewText: string);
    function UrlDecode(const S: string): string;
    function ValidaCamposAPI: Boolean;
    function ValidaCamposRoute: Boolean;
    procedure ValueListFromJSON(VLE: TValueListEditor; AStrJson: string);
    function ValueListToJSON(VLE: TValueListEditor): string;
    procedure CarregaTreeView;
    procedure LimparCamposApi;
    procedure LimparCamposRequest;
    procedure LimparCamposFields;
    procedure Api_Ler(AIdApi: Integer);
    function Api_Salvar: Boolean;
    procedure Api_Deletar;
    procedure Rota_Salvar(AShowMessage: Boolean = True);
    procedure Rota_Deletar;
    procedure Rota_Ler(AIdEndpoint: Integer);
    procedure GetTokenFromResponseBody(AData: string);
    function JsonIsValid(const AStrJson: string): string;
  public

  end;

var
  frmViewMain: TfrmViewMain;

implementation

uses
  StrUtils, LCLIntf, fpjson, jsonparser, HTTPDefs, fphttpclient, ssockets, DateUtils,
  DB, SQLDB, ZDataset, base64, sha1,
  Util.JsonFloat, Service.Api, Service.Endpoint,
  Util.GeraDoc, Util.ImportaApi;

var
  CurrentRoute: TRouteInfo = nil;

{$R *.lfm}

{ TApiInfo }

constructor TApiInfo.Create(AApiID: Integer; AApiName, AApiHost, AApiVersao: String);
begin
  FApiID := AApiID;                   // ID da tabela "api"
  FAPIName := AApiName;               // Nome da API
  FApiHost := AApiHost;               // Host da API
  FApiVersao := AApiVersao;           // Versão da API: /api/v1
end;

{ TGroupInfo }

constructor TGroupInfo.Create(AApiInfo: TApiInfo; ARouteGroup: String);
begin
  FApiInfo := AApiInfo;
  FRouteGroup := ARouteGroup;
end;

{ TRouteInfo }

constructor TRouteInfo.Create(AApiID: Integer; AApiName, AApiHost, AApiVersao: String;
                              ARouteID: Integer; ARouteGroup, ARouteMethod, ARoutePath: string);
begin
  FApiInfo := TApiInfo.Create(AApiID, AApiName, AApiHost, AApiVersao);
  //rota
  FRouteID := ARouteID;         // ID da tabela "endpoint"
  FRouteGroup := ARouteGroup;   // Grupo da rota
  FRouteMethod := ARouteMethod; // Metodo: Post, Get, Put, Delete
  FRoutePath := ARoutePath;     // Ex: /product/1
  end;

{ TfrmViewMain }

procedure TfrmViewMain.FormDestroy(Sender: TObject);
begin
  CurrentRoute := nil;
  ClearTree;
end;

procedure TfrmViewMain.FormDropFiles(Sender: TObject; const FileNames: array of string);
var
  P: TPoint;
begin
  P := ScreenToClient(Mouse.CursorPos);
  // Verifica se o controle é a TreeView
  if (PtInRect(tvCollections.BoundsRect, P)) then begin
    ImportarAPI(FileNames[0]);
  end;
end;

procedure TfrmViewMain.FormShow(Sender: TObject);
begin
  pgRequest.PageIndex := 0;
  pgResponse.PageIndex := 0;
  lblResStatusCode.Caption := '';
  tvCollections.FullExpand;
  tvCollections.DragMode := dmAutomatic;
  tvCollections.DefaultItemHeight := 20;

  FDefaultExpiration := -1001;
  FTokenExpireAt := FDefaultExpiration;

  //para que o evento onClick só dispare se clicar numa célula
  sgFields.AllowOutboundEvents := False;

  LimparCamposApi;
  CarregaTreeView;
end;

procedure TfrmViewMain.lblBodyAllFieldsClick(Sender: TObject);
begin
  PegaTodosOsCampos(True);
end;

procedure TfrmViewMain.lblHeaderImportarAPIClick(Sender: TObject);
// importar dados de uma api e suas rotas
begin
  with TOpenDialog.Create(self) do
  begin
    Caption := 'Importar dados de API';
    Filter := 'Arquivo JSON (*.json)|*.json| (*.json)|*.json';
    InitialDir := ExtractFileDir( ParamStr(0) );
    if Execute then
      ImportarAPI(FileName);
  end;
end;

procedure TfrmViewMain.lblHeaderRecarregarClick(Sender: TObject);
begin
  CarregaTreeView;
end;

procedure TfrmViewMain.lblHeaderResizeClick(Sender: TObject);
begin
  if Width < Constraints.MaxWidth then begin
    Width := Constraints.MaxWidth;
    Height := Constraints.MaxHeight;
    tvCollections.Width := 372;
  end else begin
    Width := Constraints.MinWidth;
    Height := Constraints.MinHeight;
    tvCollections.Width := 272;
  end;
end;

procedure TfrmViewMain.btnEnviarRequisicaoClick(Sender: TObject);
// faz a requisição ao servidor da api
var
  Client: TFPHTTPClient;
  Data: TStringStream;
  //Response: TStringStream;
  Response: TMemoryStream;
  SS: TStringStream;
  lJSON: TJSONObject;
  lError, lHost, k, v, DataString, LFileName, lContentTypeRetorno: string;
  i: integer;
  T1,T2 : QWord;
  Elapsed : Int64;
begin
  lError := '';
  DataString := '';
  lblResStatusCode.Caption := '';
  edtResHeaders.Clear;
  edtResBody.Clear;
  lblResEndPoint.Caption := '';

  if Trim(edtReqGrupo.Text) = '' then begin
    ShowMessage('Informe o grupo desta rota!');
    edtReqGrupo.SetFocus;
    Exit;
  end;

  if (cboReqAuthentication.Text = 'JWT') and (Trim(edtAuthToken.Text) = '') then begin
    ShowMessage('Rota requer token de autenticação!');
    Exit;
  end
  else if (cboReqAuthentication.Text = 'BASIC') and
     (Trim(edtAuthUsername.Text) <> '') and
     (Trim(edtAuthPassword.Text) <> '') then begin
    ShowMessage('Rota requer Username e Password para autenticação!');
  end;

  if (Trim(edtReqBody.Text) <> '') and (cboReqContentType.Text = 'application/json') then begin
    // valida o json antes de enviar
    lError := JsonIsValid( edtReqBody.Text );

    if lError <> '' then begin
      ShowMessage('Body: JSON inválido!' + sLineBreak + sLineBreak + lError);
      edtReqBody.SetFocus;
      Exit;
    end;
  end;

  // salva a rota no db
  Rota_Salvar(False);

  lError := '';
  Client := TFPHTTPClient.Create(nil);
  Client.AddHeader('User-Agent', 'Topazzio Rest API/1.0');
  Data := TStringStream.Create('');
  Response := TStringStream.Create('');
  lJSON := TJSONObject.Create;
  lHost := FormatHost(edtApiHost.Text, edtReqPrefixo.Text, edtReqHostPath.Text); //Ex: http://localhost:8083/api/v1/login
  lblResEndPoint.Caption := cboReqMethods.Text + ' ' + lHost;

  try

    try
      //lJSON.Add('username1','admin');
      //lJSON.Add('password','123');
      //Data.WriteString(lJSON.AsJSON);
      //Data.Position := 0;
      //Client.RequestBody := Data;

      { CONFIGURAÇÕES DA REQUISIÇÃO }

      // Se houver erro HTTP (401, 500, etc)
      Client.AllowRedirect := True;

      // Aba Headers
      for i := 1 to reqValueListEditor.RowCount-1 do begin
        K := Trim(reqValueListEditor.Keys[I]);
        V := Trim(reqValueListEditor.Values[K]);

        if (V <> '') and (K <> '' ) then
          Client.AddHeader(K, V);
      end;

      // Content-Type
      Client.AddHeader('Content-Type', Trim(cboReqContentType.Text));

      // Autenticação
      if (cboReqAuthentication.Text = 'JWT') then
        Client.AddHeader('Authorization', 'Bearer ' + edtAuthToken.Text)
      else if (cboReqAuthentication.Text = 'BASIC') then
        Client.AddHeader('Authorization', 'Basic ' + EncodeStringBase64(edtAuthUsername.Text + ':' + edtAuthPassword.Text));

      // Body (precisa ser em formato json)
      if Trim(edtReqBody.Text) <> '' then begin
        //Client.RequestBody := TStringStream.Create('{"username":"admin","password":"123"}');
        Client.RequestBody := TStringStream.Create( Trim(edtReqBody.Text) );
      end;

      T1 := GetTickCount64;

      case cboReqMethods.Text of
        'GET': begin
           Client.Get(lHost, Response);
        end;
        'PATCH': begin
           Client.HTTPMethod('PATCH', lHost, Response, []);
        end;
        'POST': begin
           Client.Post(lHost, Response);
        end;
        'PUT': begin
           Client.Put(lHost, Response);
        end;
        'DELETE': begin
           Client.Delete(lHost, Response);
        end;
      else
        begin
          ShowMessage('Método inválido');
          Exit;
        end;
      end;

      { RESPOSTA DA REQUISIÇÃO }

      T2 := GetTickCount64;
      Elapsed := T2-T1;

      // Arquivo Anexo
      LFileName := ExtractFileNameFromDisposition(Client.ResponseHeaders.Values['Content-Disposition']);
      lContentTypeRetorno := LowerCase(Client.ResponseHeaders.Values['Content-Type']);

      if (Pos('application/pdf', lContentTypeRetorno) > 0) or
         (Pos('application/xml', lContentTypeRetorno) > 0) or
         (Pos('application/html', lContentTypeRetorno) > 0) or
         (LFileName <> '') then
      begin
        if (Trim(LFileName) = '') and (Pos('application/xml', lContentTypeRetorno) > 0) then
          LFileName := 'arquivo.xml';

        if (Trim(LFileName) = '') and (Pos('application/html', lContentTypeRetorno) > 0) then
          LFileName := 'arquivo.html';

        if Trim(LFileName) <> '' then begin
          with SaveDialog1 do begin
            FileName := LFileName;
            if Execute then
              LFileName := FileName
            else
              LFileName := '';
          end;

          if LFileName <> '' then
          begin
            try
              Response.Position := 0;
              Response.SaveToFile( LFileName );

              if FileExists(LFileName) then begin
                {$IFDEF WINDOWS}
                OpenURL(ExpandFileName(LFileName));
                {$ELSE}
                OpenURL('file://' + ExpandFileName(LFileName));
                {$ENDIF}
              end;
            except
              on E: Exception do begin
                ShowMessage('Falha ao salvar o arquivo' + sLineBreak + E.Message);
              end;
            end;
          end
          else
            ShowMessage('Operação cancelada');
        end else
          ShowMessage('Não encontrei o nome do arquivo recebido no header');
      end
      else begin
        // qualquer outro tipo de dados
        Response.Position := 0;
        SS := TStringStream.Create('');
        try
          SS.CopyFrom(Response, 0);
          DataString := SS.DataString;
        finally
          SS.Free;
        end;
      end;

      // status code
      lblResStatusCode.Caption := Client.ResponseStatusCode.ToString + ' ' + Client.ResponseStatusText;

      // headers
      edtResHeaders.Lines.Add( client.ResponseHeaders.Text );

      // body
      edtResBody.Text := GetResponseBody( DataString,
                                          Client.ResponseStatusCode,
                                          Client.ResponseHeaders.Values['Content-Type'],
                                          Client.ResponseStatusText );

      // Token
      GetTokenFromResponseBody( DataString );


      //Token := Client.ResponseHeaders.Values['Authorization'];
      //ou
      //Token := Client.ResponseHeaders.Values['Set-Cookie'];
    except
      on E: ESocketError do begin
        lError := E.Message;
        T2 := GetTickCount64;
        Elapsed := T2-T1;
        // status code
        if Client.ResponseStatusCode > 0 then
          lblResStatusCode.Caption := Client.ResponseStatusCode.ToString + ' ' + Client.ResponseStatusText
        else
          lblResStatusCode.Caption := 'Connection error';

        // headers
        if Length(client.ResponseHeaders.Text)>0 then
          edtResHeaders.Lines.Add(client.ResponseHeaders.Text);
        edtResHeaders.Lines.Add('ESocketError');
        edtResHeaders.Lines.Add(E.Message);
        // body
        edtResBody.Lines.Add(DataString);
      end;
      on E: Exception do begin
        lError := E.Message;
        T2 := GetTickCount64;
        Elapsed := T2-T1;
        // status code
        if Client.ResponseStatusCode > 0 then
          lblResStatusCode.Caption := Client.ResponseStatusCode.ToString + ' ' + Client.ResponseStatusText
        else
          lblResStatusCode.Caption := 'Connection error';

        // headers
        if Length(client.ResponseHeaders.Text)>0 then
          edtResHeaders.Lines.Add(client.ResponseHeaders.Text);
        edtResHeaders.Lines.Add('Exception');
        edtResHeaders.Lines.Add(E.Message);
        // body
        edtResBody.Lines.Add(DataString);
      end;
    end;
  finally
    lJSON.Free;
    Client.RequestBody.Free;
    Client.Free;
    Data.Free;
    Response.Free;
  end;

  edtResHeaders.Lines.Add('Tempo de resposta: ' + FloatToStr(Elapsed) + ' ms');

  if lError <> '' then
    ShowMessage(lError);
end;

procedure TfrmViewMain.btnParam_AdicionarClick(Sender: TObject);
begin
  if (Trim(edtParam_Name.Text) = '') or
     (Trim(cboParam_Type.Text) = '') then
  begin
    ShowMessage('Informe os campos Requeridos!' + sLineBreak + sLineBreak +
                'Parameter Name, Type');
    Exit;
  end;

  ParamsAdd( Trim(edtParam_Name.Text),
             Trim(cboParam_Type.Text),
             Trim(edtParam_Descricao.Text)
           );

  LimparCamposParams;
  edtParam_Name.SetFocus;
end;

procedure TfrmViewMain.btnParam_DeletarClick(Sender: TObject);
begin
  if sgParams.Row > 0 then begin
    if QuestionDlg('Atenção','Confirma a exclusão deste registro ?', mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') <> mrYes then
      Exit;

    sgParams.DeleteRow(sgParams.Row);
    LimparCamposParams;
  end;
end;

procedure TfrmViewMain.btnParam_LimparClick(Sender: TObject);
begin
  LimparCamposParams;
  edtParam_Name.SetFocus;
end;

procedure TfrmViewMain.cboReqAuthenticationChange(Sender: TObject);
begin
  AuthenticationChanged;
end;

procedure TfrmViewMain.cboReqMethodsChange(Sender: TObject);
begin
  MethodChanged;
end;

procedure TfrmViewMain.edtApiHostExit(Sender: TObject);
var
  lHost: string;
begin
  lHost := Trim(edtApiHost.Text);
  if Length(lHost) = 0 then Exit;

  if not lHost.StartsWith('http://', True) and
     not lHost.StartsWith('https://', True) then
     edtApiHost.Text := 'http://' + edtApiHost.Text;

  while RightStr(edtApiHost.Text, 1) = '/' do
    edtApiHost.Text := LeftStr(edtApiHost.Text, Length(edtApiHost.Text)-1);
end;

procedure TfrmViewMain.edtApiVersaoExit(Sender: TObject);
begin
  while RightStr(edtApiVersao.Text, 1) = '/' do
    edtApiVersao.Text := LeftStr(edtApiVersao.Text, Length(edtApiVersao.Text)-1);

  if LeftStr(edtApiVersao.Text, 1) <> '/' then
    edtApiVersao.Text := '/' + edtApiVersao.Text;
end;

procedure TfrmViewMain.edtReqBodyEnter(Sender: TObject);
var
  lBody: string;
begin
  if Trim(edtReqBody.Text) <> '' then Exit;
  if sgFields.RowCount < 2 then Exit;

  lBody := BodyFromFields(FieldsToJson(), True);

  if (edtReqHostPath.Text = '/login') then begin
    if lBody <> '' then
       edtReqBody.Text := lBody
    else
      edtReqBody.Text := '{'#13'"username": "admin",'#13'"password": "123"'#13'}'
  end else begin
    if (cboReqMethods.Text = 'POST') or
       (cboReqMethods.Text = 'PUT') or
       (cboReqMethods.Text = 'PATCH') then begin
      edtReqBody.Clear;
      edtReqBody.Lines.Add( lBody );
    end;
  end;
end;

procedure TfrmViewMain.edtReqGrupoExit(Sender: TObject);
begin
  if Trim(edtReqGrupo.Text) = '' then Exit;
  edtReqGrupo.Text := ReplaceStr(edtReqGrupo.Text, '/', '');
end;

procedure TfrmViewMain.edtReqHostPathExit(Sender: TObject);
var
  s: array of string;
  d: string;
  i: integer;
begin
  if (LeftStr(edtReqHostPath.Text, 1) <> '/') and (Length(edtReqHostPath.Text) > 1) then begin
    try
      s := String(edtReqHostPath.Text).Split(['/'], TStringSplitOptions.ExcludeEmpty);

      if High(s) >= 0 then begin
        d := Trim(s[0]);
        i := Pos('?', d);
        if i > 0 then d := Copy(d, 1, i-1);
        edtReqGrupo.Text := UpperCase(Copy(d,1,1)) + Copy(d,2,Length(d));
      end;

      SetLength(s, 0);
    finally
    end;
  end;
end;

procedure TfrmViewMain.edtReqPrefixoExit(Sender: TObject);
begin
  if Trim(edtReqPrefixo.Text) <> '' then begin
    while RightStr(edtReqPrefixo.Text, 1) = '/' do
      edtReqPrefixo.Text := LeftStr(edtReqPrefixo.Text, Length(edtReqPrefixo.Text)-1);

    if LeftStr(edtReqPrefixo.Text, 1) <> '/' then
      edtReqPrefixo.Text := '/' + edtReqPrefixo.Text;
  end;
end;

procedure TfrmViewMain.FormCreate(Sender: TObject);
begin
  JsonFloatNumber;
end;

procedure TfrmViewMain.reqValueListEditorValidateEntry(Sender: TObject; aCol,
  aRow: Integer; const OldValue: string; var NewValue: String);
begin
  if aCol<>0 then Exit;

  //if NewValue in ['id','token','auth'] then begin
  //  ShowMessage('Nomes reservados');
  //  Exit;
  //end;

  NewValue := Trim(NewValue);

  if NewValue = '' then begin
    { remove a linha em branco }
    if (Trim(reqValueListEditor.Keys[aRow]) = '') and
       (Trim(reqValueListEditor.Values[reqValueListEditor.Keys[aRow]]) = '') then begin
      reqValueListEditor.DeleteRow(aRow);
      Exit;
    end;
    { campo Key em branco }
    if (Trim(reqValueListEditor.Keys[aRow]) = '') and
       (Trim(reqValueListEditor.Values[reqValueListEditor.Keys[aRow]]) <> '') then begin
      ShowMessage('Informe o campo Key');
      Exit;
    end;
    { campo Value em branco }
    if (Trim(reqValueListEditor.Keys[aRow]) <> '') and
       (Trim(reqValueListEditor.Values[reqValueListEditor.Keys[aRow]]) = '') then begin
      ShowMessage('Informe o campo Value');
      Exit;
    end;
  end;

  if KeyExists(reqValueListEditor, NewValue, aRow) then begin
    ShowMessage('Key já existe!');
    NewValue := OldValue;
  end;
end;

procedure TfrmViewMain.sgFieldsClick(Sender: TObject);
begin
  if sgFields.Row > 0 then begin // Evita ler a linha de título
    LimparCamposFields;
    btnFields_Adicionar.ImageIndex := 4;
    FFieldRow := sgFields.Row;
    edtFields_Name.Text := sgFields.Cells[0, sgFields.Row];
    cboFields_Type.Text := sgFields.Cells[1, sgFields.Row];
    edtFields_MaxLength.Text := sgFields.Cells[2, sgFields.Row];
    chkFields_Requerid.Checked := sgFields.Cells[3, sgFields.Row] = 'yes';
    edtFields_Descricao.Text := sgFields.Cells[4, sgFields.Row];
    edtFields_Name.SetFocus;
  end;
end;

procedure TfrmViewMain.sgFieldsDrawCell(Sender: TObject; aCol, aRow: Integer;
  aRect: TRect; aState: TGridDrawState);
begin
  if gdSelected in aState then begin
    sgFields.Canvas.Brush.Color := clYellow; // selected background color
    sgFields.Canvas.Font.Color := clBlue;    // selected font color
  end;

  sgFields.DefaultDrawCell(aCol, aRow, aRect, aState);
end;

procedure TfrmViewMain.sgParamsClick(Sender: TObject);
begin
  if sgParams.Row > 0 then begin // Evita ler a linha de título
    LimparCamposParams;
    btnParam_Adicionar.ImageIndex := 4;
    FparamRow := sgParams.Row;
    edtparam_Name.Text := sgParams.Cells[0, sgParams.Row];
    cboparam_Type.Text := sgParams.Cells[1, sgParams.Row];
    edtparam_Descricao.Text := sgParams.Cells[2, sgParams.Row];
    edtparam_Name.SetFocus;
  end;
end;

procedure TfrmViewMain.sgParamsDrawCell(Sender: TObject; aCol, aRow: Integer;
  aRect: TRect; aState: TGridDrawState);
begin
  if gdSelected in aState then begin
    sgParams.Canvas.Brush.Color := clYellow; // selected background color
    sgParams.Canvas.Font.Color := clBlue;    // selected font color
  end;

  sgParams.DefaultDrawCell(aCol, aRow, aRect, aState);
end;

procedure TfrmViewMain.TabEnter(Sender: TObject);
begin
  (Sender as TTabSheet).Font.Color := clBlue;
end;

procedure TfrmViewMain.TabLeave(Sender: TObject);
begin
  (Sender as TTabSheet).Font.Color := clDefault;
end;

procedure TfrmViewMain.tvCollectionsAdvancedCustomDrawItem(
  Sender: TCustomTreeView; Node: TTreeNode; State: TCustomDrawState;
  Stage: TCustomDrawStage; var PaintImages, DefaultDraw: Boolean);
begin
  if cdPrePaint = Stage then begin
    if Node = tvCollections.Selected then begin
      Sender.Canvas.Font.Style := [fsBold];
    end else begin
      Sender.Canvas.Font.Style := [];
    end;
  end;
end;

procedure TfrmViewMain.tvCollectionsClick(Sender: TObject);
var
  infoApi: TApiInfo;     {Não destruir estes objetos aqui}
  infoGroup: TGroupInfo;
  infoRoute: TRouteInfo;
begin
  if Assigned(tvCollections.Selected) then begin

    { Node da API }

    if TObject( tvCollections.Selected.Data ) is TApiInfo then begin
       infoApi := TApiInfo( tvCollections.Selected.Data );
       if Assigned(infoApi) then begin
         Api_Salvar;
         Api_Ler(infoApi.ApiID);
         pgRequest.PageIndex := 0;
       end;
    end

    { Node do Grupo }

    else if TObject( tvCollections.Selected.Data ) is TGroupInfo then begin
       infoGroup := TGroupInfo( tvCollections.Selected.Data );
       if Assigned(infoGroup) then begin
         Api_Salvar;
         Api_Ler(infoGroup.ApiInfo.ApiID);
         pgRequest.PageIndex := 5;
         edtReqGrupo.Text := infoGroup.RouteGroup;
         edtReqHostPath.SetFocus;
       end;
    end

    { Node da Rota }

    else if TObject( tvCollections.Selected.Data ) is TRouteInfo then begin
      infoRoute := TRouteInfo( tvCollections.Selected.Data );

      if Assigned(infoRoute) then begin
        Api_Salvar;
        CurrentRoute := infoRoute;
        Rota_Ler(infoRoute.RouteID);
      end;
    end;
  end;
end;

procedure TfrmViewMain.btnNovaRotaClick(Sender: TObject);
var
  s: string;
begin
  //if RouteExists(CurrentRoute) then Exit;
  s := Trim(edtReqGrupo.Text);
  Api_Salvar;
  LimparCamposRequest;
  pgRequest.PageIndex := 5;
  CurrentRoute := nil;
  edtReqGrupo.Text := s;
  edtReqHostPath.SetFocus;
  tvCollections.Selected := nil;
end;

procedure TfrmViewMain.btnDeletarRotaClick(Sender: TObject);
//Se remover última rota, a coleção também some automaticamente
begin
  if FRouteId < 1 then Exit;

  if QuestionDlg('Atenção','Deseja Deletar esta Rota ?', mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') <> mrYes then
    Exit;

  if Assigned(CurrentRoute) then begin
    DeleteRoute;  // na treeview
    Rota_Deletar; // no DB
    LimparCamposRequest;
    tvCollections.Selected := nil;
    //CarregaTreeView;
  end;
end;

procedure TfrmViewMain.btnNovaApiClick(Sender: TObject);
begin
  Api_Salvar;
  LimparCamposApi;
  pgRequest.PageIndex := 0;
  CurrentRoute := nil;
  edtApiName.SetFocus;
end;

procedure TfrmViewMain.btnDeletarApiClick(Sender: TObject);
begin
  if FApiId < 1 then Exit;
  if QuestionDlg('Atenção','Deseja Deletar esta API e suas Rotas ?', mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') <> mrYes then
    Exit;

  Api_Deletar;
  CarregaTreeView;
end;

procedure TfrmViewMain.btnFields_AdicionarClick(Sender: TObject);
// [sgFields.Cel, sgFields.Row]
begin
  if (Trim(edtFields_Name.Text) = '') or
     (Trim(cboFields_Type.Text) = '') or
     (Trim(edtFields_MaxLength.Text) = '') then
  begin
    ShowMessage('Informe os campos Requeridos!' + sLineBreak + sLineBreak +
                'Field Name, Field Type, Length');
    Exit;
  end;

  FieldsAdd( Trim(edtFields_Name.Text),
             Trim(cboFields_Type.Text),
             Trim(edtFields_MaxLength.Text),
             Trim(edtFields_Descricao.Text),
             chkFields_Requerid.Checked
           );

  LimparCamposFields;
  edtFields_Name.SetFocus;
end;

procedure TfrmViewMain.btnFields_DeletarClick(Sender: TObject);
begin
  if sgFields.Row > 0 then begin
    if QuestionDlg('Atenção','Confirma a exclusão deste registro ?', mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') <> mrYes then
      Exit;

    sgFields.DeleteRow(sgFields.Row);
    LimparCamposFields;
  end;
end;

procedure TfrmViewMain.btnFields_LimparClick(Sender: TObject);
begin
  LimparCamposFields;
  edtFields_Name.SetFocus;
end;

procedure TfrmViewMain.btnGerarDocClick(Sender: TObject);
// gera a documentação da api
var
  doc: TUtilGeraDoc;
begin
  if FApiId < 1 then Exit;
  if QuestionDlg('Atenção','Gerar a documentação desta API ?', mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') <> mrYes then
    Exit;

  doc := TUtilGeraDoc.Create;

  if doc.GeraDocumento(FApiId, imgLogoDoc) then begin
    if QuestionDlg('Documento','Documento gerado com sucesso!' + sLineBreak + sLineBreak + 'Deseja exibir o documento ?', mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') = mrYes then
      OpenURL(doc.GetDocumentoPath); // LCLIntf
  end else
    ShowMessage(doc.GetErroMsg);

  FreeAndNil(doc);
end;

procedure TfrmViewMain.ButtonMouseEnter(Sender: TObject);
begin
  (Sender as TSpeedButton).Font.Color := clBlue;
end;

procedure TfrmViewMain.ButtonMouseLeave(Sender: TObject);
begin
  (Sender as TSpeedButton).Font.Color := clDefault;
end;

procedure TfrmViewMain.AddRoute(ARouteInfo: TRouteInfo; ASelectThis: Boolean);
// adiciona rota a coleção
var
  RootNode, ApiNode, ColNode, RouteNode : TTreeNode;
  I, J : Integer;
  lApiName: string;
begin
  // Nó principal
  RootNode := nil;

  for I := 0 to tvCollections.Items.Count-1 do
    if (tvCollections.Items[I].Level = 0) and (tvCollections.Items[I].Text = 'APIs') then begin
      RootNode := tvCollections.Items[I];
      Break;
    end;

  if RootNode = nil then begin
    RootNode := tvCollections.Items.Add(nil, 'APIs');
    RootNode.ImageIndex := 0;
    RootNode.SelectedIndex := 0;
  end;

  // Nó da API
  lApiName := ARouteInfo.ApiInfo.ApiName;
  if ARouteInfo.ApiInfo.ApiVersao <> '' then
    lApiName := lApiName + ' - ' + ARouteInfo.ApiInfo.ApiVersao;

  ApiNode := nil;

  for I := 0 to RootNode.Count-1 do
    if (RootNode.Items[I].Data <> nil) and
       (TObject(RootNode.Items[I].Data) is TApiInfo) and
       (TApiInfo(RootNode.Items[I].Data).ApiID = ARouteInfo.ApiInfo.ApiID) then begin
      ApiNode := RootNode.Items[I];
      Break;
    end;

  if ApiNode = nil then
    ApiNode := tvCollections.Items.AddChild(RootNode, lApiName);

  ApiNode.ImageIndex := 1;
  ApiNode.Data := TApiInfo.Create(ARouteInfo.ApiInfo.ApiID,
                                  ARouteInfo.ApiInfo.ApiName,
                                  ARouteInfo.ApiInfo.ApiHost,
                                  ARouteInfo.ApiInfo.ApiVersao);

  // Nó do agrupamento de rotas
  ColNode := nil;

  for J := 0 to ApiNode.Count-1 do
    if ApiNode.Items[J].Text = ARouteInfo.RouteGroup then begin
      ColNode := ApiNode.Items[J];
      Break;
    end;

  if ColNode = nil then
    ColNode := tvCollections.Items.AddChild(ApiNode, ARouteInfo.RouteGroup);

  ColNode.ImageIndex := 2;
  ColNode.Data := TGroupInfo.Create(ARouteInfo.ApiInfo, ARouteInfo.RouteGroup);

  // Nó de rotas dentro do agrupamento de rotas
  RouteNode := nil;

  for J := 0 to ColNode.Count - 1 do
    if (ColNode.Items[J].Data <> nil) and (TObject(ColNode.Items[J].Data) is TRouteInfo) then begin
      if TRouteInfo(ColNode.Items[J].Data).RouteID = ARouteInfo.RouteID then begin
        RouteNode := ColNode.Items[J];
        Break;
      end;
    end;

  if RouteNode = nil then
    RouteNode := tvCollections.Items.AddChild(ColNode, ARouteInfo.RouteMethod + ' ' + SimplifyRoute(ARouteInfo.RoutePath));
  RouteNode.Data := ARouteInfo;

  // define icone da rota
  if ARouteInfo.RouteMethod = 'GET' then RouteNode.ImageIndex := 3;
  if ARouteInfo.RouteMethod = 'POST' then RouteNode.ImageIndex := 4;
  if ARouteInfo.RouteMethod = 'PUT' then RouteNode.ImageIndex := 5;
  if ARouteInfo.RouteMethod = 'DELETE' then RouteNode.ImageIndex := 6;
  if ARouteInfo.RouteMethod = 'PATCH' then RouteNode.ImageIndex := 7;

  RouteNode.SelectedIndex := RouteNode.ImageIndex;

  // expande os nós
  RootNode.Expand(True);
  ApiNode.Expand(True);

  if ASelectThis then
    tvCollections.Selected := RouteNode;
end;

procedure TfrmViewMain.DeleteRoute;
var
  LNode       : TTreeNode;
  LGroupNode  : TTreeNode;
  LApiNode    : TTreeNode;
begin
  LNode := tvCollections.Selected;

  if LNode = nil then Exit;

  if LNode.Level <> 3 then Exit; // rota

  // encontra o nó do grupo da rota e da api
  LGroupNode := LNode.Parent;
  LApiNode := LGroupNode.Parent;

  // remove a rota e o objeto TRouteInfo;
  if Assigned(LNode.Data) then
    TObject(LNode.Data).Free;

  LNode.Delete;

  // deleta o grupo da rota e o objeto TGroupInfo, se não contiver filhos
  if (LGroupNode <> nil) and (LGroupNode.Count = 0) then begin
    if Assigned(LGroupNode.Data) then
      TObject(LGroupNode.Data).Free;
    LGroupNode.Delete;
  end;

  // deleta a árvore da api e o objeto TApiInfo, se a mesma não contiver filhos
  if (LApiNode <> nil) and (LApiNode.Count = 0) then begin
    if Assigned(LApiNode.Data) then
      TObject(LApiNode.Data).Free;
    LApiNode.Delete;
  end;

  CurrentRoute := nil;
end;

function TfrmViewMain.FindRouteNode(ARouteInfo: TRouteInfo):TTreeNode;
// Node := FindRouteNode(...);
// Node.Text := 'PUT /produtos/7';
var
  I : Integer;
  Info : TRouteInfo;
begin
  Result := nil;
  if ARouteInfo = nil then Exit;

  for I := 0 to tvCollections.Items.Count-1 do begin
    if Assigned(tvCollections.Items[I].Data) and
       (TObject( tvCollections.Items[I].Data ) is TRouteInfo) then
    begin
      Info := TRouteInfo(tvCollections.Items[I].Data);

      if Assigned(Info) then begin
        if (Info.ApiInfo.ApiID = ARouteInfo.ApiInfo.ApiId) and
           (Info.RouteID = ARouteInfo.RouteID) then
        begin
          Result := tvCollections.Items[I];
          Exit;
        end;
      end; // if
    end;
  end; // for
end;

function TfrmViewMain.RouteExists(ARouteInfo: TRouteInfo; AUpdate: Boolean): Boolean;
// verifica se a rota já existe conforme Group, Method e Route/Path
var
  I : Integer;
  Info : TRouteInfo;
begin
  Result := False;
  if ARouteInfo = nil then Exit;

  for I := 0 to tvCollections.Items.Count-1 do begin
    if Assigned(tvCollections.Items[I].Data) and
       (TObject( tvCollections.Items[I].Data ) is TRouteInfo) then
    begin
      Info := TRouteInfo(tvCollections.Items[I].Data);

      if Assigned(Info) then begin
        if (Info.ApiInfo.ApiID = ARouteInfo.ApiInfo.ApiID) and
           SameText(Info.RouteGroup, ARouteInfo.RouteGroup) and
           SameText(Info.RouteMethod, ARouteInfo.RouteMethod) and
           MatchRoute(SimplifyRoute(Info.RoutePath), SimplifyRoute(ARouteInfo.RoutePath)) then
        begin
          if AUpdate and (Info.RouteID = ARouteInfo.RouteID) then begin
            tvCollections.Items[I].Data := CurrentRoute;
            tvCollections.Items[I].Text := CurrentRoute.RouteMethod + ' ' + CurrentRoute.RoutePath;
          end;

          Result := True;
          Exit;
        end;
      end;
    end;
  end;
end;

procedure TfrmViewMain.UpdateSelectedRoute(const ANewText:string);
begin
  if Assigned(tvCollections.Selected) then
    tvCollections.Selected.Text := ANewText;
end;

procedure TfrmViewMain.RenameCollection(const AOldName, ANewName:string);
var
  I : Integer;
begin
  for I := 0 to tvCollections.Items.Count-1 do
    if tvCollections.Items[I].Text = AOldName then begin
      tvCollections.Items[I].Text := ANewName;
      Break;
    end;
end;

function TfrmViewMain.TreeToJSON(Tree:TTreeView):string;
var
  RootObj      : TJSONObject;
  ApiObj       : TJSONObject;
  ColArr       : TJSONArray;
  RouteObj     : TJSONObject;
  ApiNode      : TTreeNode;
  ColNode      : TTreeNode;
  RouteNode    : TTreeNode;
  Info         : TRouteInfo;
  I,J,K        : Integer;
  sHost        : String;
  bAddHost     : Boolean;
begin
  RootObj := TJSONObject.Create;

  try
    if Tree.Items.Count = 0 then begin
      Result := '{}';
      Exit;
    end;

    for I := 0 to Tree.Items[0].Count-1 do begin
      ApiNode := Tree.Items[0].Items[I];
      ApiObj := TJSONObject.Create;
      sHost := '';
      bAddHost := False;

      for J := 0 to ApiNode.Count-1 do begin
        ColNode := ApiNode.Items[J];
        ColArr := TJSONArray.Create;

        for K := 0 to ColNode.Count-1 do begin
          RouteNode := ColNode.Items[K];
          Info := TRouteInfo(RouteNode.Data);
          sHost := Info.ApiInfo.ApiHost;

          if Assigned(Info) then begin
            RouteObj := TJSONObject.Create;
            RouteObj.Add('method', Info.RouteMethod);
            RouteObj.Add('route', Info.RoutePath);

            ColArr.Add(RouteObj);
          end;
        end;

        if not bAddHost then begin
          ApiObj.Add('host', sHost);
          bAddHost := True;
        end;

        ApiObj.Add(ColNode.Text, ColArr);
      end;

      RootObj.Add(ApiNode.Text, ApiObj);
    end;

    Result := RootObj.FormatJSON;
  finally
    RootObj.Free;
  end;
end;

function TfrmViewMain.KeyExists(VLE:TValueListEditor; const AKey:string; IgnoreRow:Integer=-1):Boolean;
// verifica se há duplicidade de KEY
var
  I : Integer;
begin
  Result := False;

  for I := 1 to VLE.RowCount-1 do begin
    if I = IgnoreRow then Continue;

    if SameText(Trim(VLE.Keys[I]), Trim(AKey)) then
      Exit(True);
  end;
end;

function TfrmViewMain.ValueListToJSON(VLE:TValueListEditor):string;
// retorna os dados Key / Value em formato string Json
var
  j : TJSONArray;
  I   : Integer;
  K,V : String;
begin
  j := TJSONArray.Create;

  try
    for I := 1 to VLE.RowCount-1 do begin
      K := Trim(VLE.Keys[I]);
      V := Trim(VLE.Values[K]);

      if (V <> '') and (K <> '' ) then begin
        j.Add(TJSONObject.Create([
                                 'key', K,
                                 'value', V
                                 ]));
      end;
    end;

    Result := j.FormatJSON;
  finally
    j.Free;
  end;
end;

procedure TfrmViewMain.ValueListFromJSON(VLE:TValueListEditor; AStrJson: string);
// carrega os dados Key / Value do json
var
  arj: TJSONArray;
  j: TJSONObject;
  I: Integer;
  K, V: string;
begin
  VLE.Strings.Clear;
  if AStrJson = '' then Exit;

  arj := TJSONArray( GetJSON(AStrJson) );

  try
    for I := 0 to arj.Count -1 do begin
      j := TJSONObject(arj.Objects[I]);
      K := Trim( j.Get('key', '') );
      V := Trim( j.Get('value', '') );

      if (K <> '') and (V <> '') then
        VLE.InsertRow(K, V, True);
    end;
  finally
    arj.Free;
  end;
end;

procedure TfrmViewMain.LimparCamposApi;
begin
  lblTopHost.Caption := '';
  FTokenExpireAt := FDefaultExpiration;
  FApiId := 0;
  edtApiName.Clear;
  edtApiHost.Clear;
  edtApiVersao.Text := '/api/v1';
  edtApiDescricao.Clear;
  edtApiHeader1.Clear;
  edtApiHeader2.Clear;
  edtApiHeader3.Clear;
  edtApiFooter1.Clear;
  edtApiFooter2.Clear;
  // aba authentication
  edtAuthUsername.Clear;
  edtAuthPassword.Clear;
  lblApiTokenValidade.Caption := '';
  edtAuthToken.Clear;

  LimparCamposRequest;

  lblReqTokenExpirou.Visible := False;
end;

procedure TfrmViewMain.LimparCamposRequest;
begin
  // Aba Request
  FRouteId := 0;
  edtReqGrupo.Clear;
  cboReqMethods.Text := 'GET';
  edtReqPrefixo.Text := edtApiVersao.Text;
  edtReqHostPath.Clear;
  cboReqAuthentication.Text := 'NONE';
  cboReqContentType.ItemIndex := 0;
  edtReqDescricao.Clear;
  edtReqBody.Clear;
  lblResEndPoint.Caption := '';

  // Aba Headers
  reqValueListEditor.Strings.Clear;

  // Aba Parameters
  sgParams.Clean;
  sgParams.RowCount := 1;
  LimparCamposParams;

  // Aba Fields
  sgFields.Clean;
  sgFields.RowCount := 1;
  LimparCamposFields;

  // Aba Respose Headers
  lblResStatusCode.Caption := '';
  edtResHeaders.Clear;
  edtResBody.Clear;
end;

procedure TfrmViewMain.LimparCamposFields;
begin
  FFieldRow := 0;
  btnFields_Adicionar.ImageIndex := 8;
  edtFields_Name.Clear;
  cboFields_Type.ItemIndex := 4;
  edtFields_MaxLength.Text := '0';
  chkFields_Requerid.Checked := False;
  edtFields_Descricao.Clear;
end;

procedure TfrmViewMain.Api_Ler(AIdApi: Integer);
// obtém dados da api
var
  api: TServiceApi;
begin
  LimparCamposApi;
  CurrentRoute := nil;

  api := TServiceApi.Create;

  if api.Ler( AIdApi  ) then begin
    lblTopHost.Caption := api.HostRoot + api.Versao;
    FApiId := api.IdApi;
    edtApiName.Text := api.ApiName;
    edtApiHost.Text := api.HostRoot;
    edtApiVersao.Text := api.Versao;
    edtApiDescricao.Text := api.Description;
    edtApiHeader1.Text := api.Header_Texto1;
    edtApiHeader2.Text := api.Header_Texto2;
    edtApiHeader3.Text := api.Header_Texto3;
    edtApiFooter1.Text := api.Footer_Texto1;
    edtApiFooter2.Text := api.Footer_Texto2;
    edtAuthUsername.Text := api.BasicUsername;
    edtAuthPassword.Text := api.BasicPassword;
    edtAuthToken.Text := api.Token;

    edtReqPrefixo.Text := api.Versao;

    MethodChanged;

    CurrentRoute := TRouteInfo.Create(api.IdApi, api.ApiName, api.HostRoot, api.Versao, 0, '', 'GET', '');

    if Trim(api.Token) <> '' then
      GetTokenFromResponseBody(Format('{"token":"%s"}', [api.Token]));
  end else
    ShowMessage(api.MensagemErro);

  api.Free;
end;

function TfrmViewMain.Api_Salvar: Boolean;
//salva a api
var
  api: TServiceApi;
  rt: TServiceEndpoint;
begin
  Result := False;
  if not ValidaCamposAPI then Exit;
  if not ValidaCamposRoute then Exit;

  api := TServiceApi.Create;
  api.ApiName       := Trim(edtApiName.Text);
  api.HostRoot      := Trim(edtApiHost.Text);
  api.Versao        := Trim(edtApiVersao.Text);
  api.Description   := Trim(edtApiDescricao.Text);
  api.Header_Texto1 := Trim(edtApiHeader1.Text);
  api.Header_Texto2 := Trim(edtApiHeader2.Text);
  api.Header_Texto3 := Trim(edtApiHeader3.Text);
  api.Footer_Texto1 := Trim(edtApiFooter1.Text);
  api.Footer_Texto2 := Trim(edtApiFooter2.Text);
  api.BasicUsername := Trim(edtAuthUsername.Text);
  api.BasicPassword := Trim(edtAuthPassword.Text);
  api.Token         := Trim(edtAuthToken.Text);

  if api.Salvar(FApiID) then begin
    FApiId := api.IdApi;
    lblTopHost.Caption := api.HostRoot + api.Versao;

    rt := TServiceEndpoint.Create( api.IdApi );
    rt.Group       := Trim(edtReqGrupo.Text);
    rt.Method      := Trim(cboReqMethods.Text);
    rt.Prefix      := Trim(edtReqPrefixo.Text);
    rt.Route       := Trim(edtReqHostPath.Text);
    rt.AuthMode    := Trim(cboReqAuthentication.Text);
    rt.ContentType := Trim(cboReqContentType.Text);
    rt.Headers     := ValueListToJSON(reqValueListEditor); //json array
    rt.Parameters  := ParamsToJson();
    rt.TableFields := FieldsToJson();
    rt.Body        := Trim(edtReqBody.Text);
    rt.Description := Trim(edtReqDescricao.Text);

    if rt.Salvar(FRouteId) then begin
      FRouteId := rt.IdEndpoint;
      CurrentRoute := TRouteInfo.Create(api.IdApi, api.ApiName, api.HostRoot, api.Versao,
                                        rt.IdEndpoint, rt.Group, rt.Method,
                                        rt.Route);
      Result := True;
    end;

    rt.Free;
  end;

  api.Free;
end;

procedure TfrmViewMain.Api_Deletar;
// deleta a api e suas rotas
var
  api: TServiceApi;
begin
  api := TServiceApi.Create;

  if api.Deletar(FApiId) then begin
    LimparCamposApi;
    CurrentRoute := nil;
  end;

  api.Free;
end;

procedure TfrmViewMain.Rota_Salvar(AShowMessage: Boolean);
// salva a api e rota
begin
  //if RouteExists(CurrentRoute) then begin
  //  if AShowMessage then
  //    ShowMessage('Esta ROTA já existe.');
  //  Exit;
  //end;

  if not ValidaCamposAPI then begin
    if AShowMessage then
      ShowMessage('Informe os dados da API');
    pgRequest.PageIndex := 0;
    edtApiName.SetFocus;
    Exit;
  end;

  if not ValidaCamposRoute then begin
    if AShowMessage then
      ShowMessage('Informe os dados da ROTA');
    Exit;
  end;

  if Api_Salvar then begin
    if not RouteExists(CurrentRoute, True) then //FindRouteNode
      AddRoute(CurrentRoute, True); // exibe na treeview
  end;
end;

procedure TfrmViewMain.Rota_Deletar;
// deleta a rota na api
var
  rt: TServiceEndpoint;
begin
  rt := TServiceEndpoint.Create(FApiId);
  rt.Deletar(FRouteId);
  rt.Free;

  LimparCamposRequest;
end;

procedure TfrmViewMain.Rota_Ler(AIdEndpoint: Integer);
// obtém dados da rota quando clicar na treeview
var
  rt: TServiceEndpoint;
begin
  LimparCamposApi;

  rt := TServiceEndpoint.Create( CurrentRoute.ApiInfo.ApiID );

  edtReqGrupo.Text := CurrentRoute.RouteGroup;

  if rt.Ler( AIdEndpoint ) then begin
    // api
    lblTopHost.Caption := rt.ApiHost + rt.ApiVersao;
    FApiId := rt.IdApi;
    edtApiName.Text := rt.ApiName;
    edtApiHost.Text := rt.ApiHost;
    edtApiVersao.Text := rt.ApiVersao;
    edtApiDescricao.Text := rt.ApiDescripion;
    edtApiHeader1.Text := rt.ApiHeader_Texto1;
    edtApiHeader2.Text := rt.ApiHeader_Texto2;
    edtApiHeader3.Text := rt.ApiHeader_Texto3;
    edtApiFooter1.Text := rt.ApiFooter_Texto1;
    edtApiFooter2.Text := rt.ApiFooter_Texto2;
    edtAuthUsername.Text := rt.ApiBasicUsername;
    edtAuthPassword.Text := rt.ApiBasicPassword;
    edtAuthToken.Text := rt.ApiToken;

    // request
    FRouteId := rt.IdEndpoint;
    pgRequest.PageIndex := 5;
    edtReqGrupo.Text := rt.Group;
    cboReqMethods.Text  := rt.Method;
    edtReqPrefixo.Text := rt.Prefix;
    edtReqHostPath.Text := rt.Route;
    cboReqAuthentication.Text := rt.AuthMode;
    cboReqContentType.Text := rt.ContentType;
    edtReqDescricao.Text := rt.Description;

    if rt.AuthMode = 'NONE' then
      imgRouteAuth.ImageIndex := 14
    else
      imgRouteAuth.ImageIndex := 13;

    MethodChanged;

    // Aba Authentication
    AuthenticationChanged;

    // Aba Headers
    ValueListFromJSON(reqValueListEditor, rt.Headers);

    // Aba Parameters
    ParamsFromJson(rt.Parameters);

    // Aba Fields
    FieldsFromJson(rt.TableFields);

    if Trim(rt.ApiToken) <> '' then
      GetTokenFromResponseBody(Format('{"token":"%s"}', [rt.ApiToken]));

    edtReqHostPath.SetFocus;
  end
  else
    ShowMessage(rt.MensagemErro);

  rt.Free;
end;

procedure TfrmViewMain.FormatJsonFromResponseBody(AContent: string);
// Dados recebidos do request
begin
  edtResBody.Text := '';
  if AContent = '' then Exit;

  if (AContent.StartsWith('{')) or (AContent.StartsWith('[')) then begin
    try
      if StringCodePage(AContent) = 0 then
        AContent := UTF8Encode(AContent);
    finally
    end;
  end;

  edtResBody.Text := AContent;
end;

procedure TfrmViewMain.GetTokenFromResponseBody(AData: string);
// extrai o token recebido. AData termina com #$0A
var
  j: TJSONObject;
  sToken: String;
  lExp: Int64;
begin
  if not AData.StartsWith('{') and not AData.StartsWith('[') then Exit;

  if (Trim(AData) <> '') then begin
    try
      j := TJSONObject( GetJSON( AData ) );

      sToken := j.Get('token', '');
      lExp   := j.Get('exp', FDefaultExpiration);

      if sToken <> '' then begin
        edtAuthToken.Text := sToken;
        lblApiTokenValidade.Caption := '';
        lblReqTokenExpirou.Visible := False;

        if lExp = FDefaultExpiration then
          lExp := GetTokenExpiration( sToken ); // tenta obter expiration de outra forma

        if lExp <> FDefaultExpiration then begin
          if lExp > DateTimeToUnix(now) then begin
            lblApiTokenValidade.Font.Color := clGreen;
            lblApiTokenValidade.Caption := Format('Expira em: %s', [FormatDateTime('yyyy-mm-dd hh:nn:ss', UnixToDateTime(lExp))]);
            FTokenExpireAt := lExp;
          end else begin
            lblApiTokenValidade.Font.Color := clRed;
            lblApiTokenValidade.Caption := 'Token Expirou';
            lblReqTokenExpirou.Visible := True;
            FTokenExpireAt := FDefaultExpiration;
            sToken := '';
          end;
        end;

        if (CurrentRoute <> nil) and (CurrentRoute.ApiInfo.ApiID > 0) then begin
          with TServiceApi.Create do begin
            SalvarToken(CurrentRoute.ApiInfo.ApiID, sToken);
          end;
        end;
      end;

    finally
      j.Free;
    end;
  end;
end;

function TfrmViewMain.JsonIsValid(const AStrJson: string): string;
// checa se o json is válido
var
  lData: TJSONData;
  lJson: TJSONObject;
  s: String;
begin
  Result := '';
  s := Trim(AStrJson);

  if s = '' then begin
    Result := 'Conteúdo em branco';
    Exit;
  end;

  try
    lData := GetJSON(s);

    if not (lData is TJSONObject) then begin
      Result := 'Não é um objeto JSON';
      Exit;
    end;

    lJson := TJSONObject(lData);
    if lJson.Count < 1 then
      Result := 'JSON não contém dados';

    lData.Free;
  except
    on E: Exception do
      Result := E.Message;
  end;
end;

function TfrmViewMain.GetResponseBody(AData: string; ACode: Integer; AContentType, ACodeText: string):string;
// Se for Json, exibe le formatado
var
  j: TJSONObject;
  lCodeText: string;
begin
  lCodeText := ACode.ToString + '-' + ACodeText;
  Result := AData;

  if AData.StartsWith('{') or AData.StartsWith('[') then begin
    try
      j := TJSONObject( GetJSON( AData ) );

      Result := j.FormatJSON();
    finally
      j.Free;
    end;
  end; // if

  if ACode >= 100 then
    with TServiceEndpoint.Create(FApiId) do begin
      if (ACode >= 200) and (ACode < 300) then
        SalvarResponseOK(FRouteId, lCodeText, AContentType, Result)
      else if (ACode < 500) then
        SalvarResponseNeg(FRouteId, lCodeText, AContentType, Result);

      Free;
    end;
end;

procedure TfrmViewMain.CarregaTreeView;
// carrega a treeview com as APIs do banco de dados
var
  api: TServiceApi;
  dados: TZQuery;
begin
  ClearTree;
  LimparCamposApi;

  api := TServiceApi.Create;
  dados := api.qryListApiCollection;

  while not dados.EOF do begin
    AddRoute(TRouteInfo.Create(dados.FieldByName('idapi').AsInteger,
                               dados.FieldByName('api_name').AsString,
                               dados.FieldByName('api_host_root').AsString,
                               dados.FieldByName('versao').AsString,
                               dados.FieldByName('idep').AsInteger,
                               dados.FieldByName('rtgroup').AsString,
                               dados.FieldByName('method').AsString,
                               SimplifyRoute(dados.FieldByName('route').AsString)
                              )
            );
    dados.Next;
  end;

  dados.Close;
  api.Free;
end;

procedure TfrmViewMain.ClearTree;
// remove todos os itens da treeview
var
  I : Integer;
  InfoApi: TApiInfo;
  infoGroup: TGroupInfo;
  InfoRoute: TRouteInfo;
begin
  for I := 0 to tvCollections.Items.Count-1 do begin
    if TObject( tvCollections.Items[I].Data ) is TApiInfo then begin
      // informações da API
      InfoApi := TApiInfo( tvCollections.Items[I].Data );
      if Assigned(InfoApi) then FreeAndNil(InfoApi);
    end else if TObject( tvCollections.Items[I].Data ) is TGroupInfo then begin
      // informações do grupo da rota
      infoGroup := TGroupInfo( tvCollections.Items[I].Data );
      if Assigned(infoGroup) then FreeAndNil(infoGroup);
    end else if TObject( tvCollections.Items[I].Data ) is TRouteInfo then begin
        // informações da rota
      InfoRoute := TRouteInfo( tvCollections.Items[I].Data );
      if Assigned(InfoRoute) then FreeAndNil(InfoRoute);
    end;
  end;

  tvCollections.Items.Clear;
end;

procedure TfrmViewMain.AuthenticationChanged;
begin
  if (cboReqAuthentication.Text <> 'NONE') then
    imgRouteAuth.ImageIndex := 13
  else
    imgRouteAuth.ImageIndex := 14;
end;

procedure TfrmViewMain.MethodChanged;
begin
  lblBodyAllFields.Font.Color := clGray;
  cboReqMethods.Font.Color := clBlack;
  edtReqBody.Clear;

  case cboReqMethods.Text of
    'GET': cboReqMethods.Font.Color := clBlue;
    'PATCH':
      begin
        cboReqMethods.Font.Color := $0035B7DB;
        lblBodyAllFields.Font.Color := clBlue;
      end;
    'POST':
      begin
        cboReqMethods.Font.Color := clGreen;
        lblBodyAllFields.Font.Color := clBlue;
      end;
    'PUT':
      begin
        cboReqMethods.Font.Color := $0013C9FC; // $0002DCDA;
        lblBodyAllFields.Font.Color := clBlue;
      end;
    'DELETE': cboReqMethods.Font.Color := clRed;
  end;
end;

function TfrmViewMain.FormatHost(AHost, AVersao, APath: string): string;
begin
  AHost := Trim(AHost);

  if Trim(AHost) = '' then AHost := 'http://localhost:8080' + AVersao;

  if not AHost.StartsWith('http://', True) and not AHost.StartsWith('https://', True) then
    AHost := 'http://' + AHost;

  if Trim(AVersao) <> '' then begin {  /api/v1/ ==> api/v1 }
    if LeftStr(AVersao, 1) = '/' then AVersao := MidStr(AVersao, 2, Length(AVersao));
    if RightStr(AVersao, 1) <> '/' then AVersao := AVersao + '/';
  end;

  if RightStr(AHost, 1) <> '/' then AHost := AHost + '/';
  if LeftStr(APath, 1) = '/' then APath := MidStr(APath, 2, Length(APath));

  Result := AHost + AVersao + APath;
end;

function TfrmViewMain.Hash_Password(const APassword, AUsername:String; AIterations:Integer=50):String;
var
  I : Integer;
  S : String;
begin
  S := APassword + LowerCase(AUsername);

  for I := 1 to AIterations do
    S := SHA1Print(SHA1String(S));

  Result := S;
end;

function TfrmViewMain.ValidaCamposAPI: Boolean;
//verifica se os campos obrigatórios forma preenchidos
begin
  Result := True;
  if Trim(edtApiName.Text) = '' then Result := False;
  if Trim(edtApiHost.Text) = '' then Result := False;
end;

function TfrmViewMain.ValidaCamposRoute: Boolean;
//verifica se os campos obrigatórios forma preenchidos
begin
  Result := True;
  if Trim(edtReqGrupo.Text) = '' then Result := False;
  if Trim(cboReqMethods.Text) = '' then Result := False;
  if Trim(edtReqHostPath.Text) = '' then Result := False;
  if Trim(cboReqContentType.Text) = '' then Result := False;
end;

function TfrmViewMain.CleanURI(const AURI: String): String;
begin
  Result := Copy(AURI, 1, Pos('?', AURI + '?')-1);

  if (Length(Result) > 1) and (Result[Length(Result)] = '/') then
    Delete(Result, Length(Result), 1);
end;

function TfrmViewMain.SimplifyRoute(const ARoute: String): String;
begin
  Result := Copy(ARoute, 1, Pos('=', ARoute + '=')-1);
end;

function TfrmViewMain.SplitParam(const S:string):TStringArray;
begin
  Result := S.Split('/', TStringSplitOptions.ExcludeEmpty);
end;

function TfrmViewMain.MatchRoute(ARouteOne, ARouteTwo: string): boolean;
{ /product/:id }
var
  r, u: TStringArray;
begin
  r := SplitParam( CleanURI(ARouteOne) );
  u := SplitParam( CleanURI(ARouteTwo) );

  if (Length(r) < 1) or (Length(u) < 1) then Exit(False);
  Result := ( LowerCase(r[0]) = LowerCase(u[0]) );
end;

function TfrmViewMain.GetTokenExpiration(AToken: string): Int64;
// tenta encontrar o tempo de expiração do token
// 'werwyeruywruywryu.yauya6ahaahsahd.iiafa8ksjfksjfk'
var
  t: array of string;
  j: TJSONObject;
begin
  Result := FDefaultExpiration;

  t := AToken.Split(['.'], TStringSplitOptions.ExcludeEmpty);

  if High(t) = 2 then begin
    try
      j := TJSONObject( GetJSON( DecodeStringBase64( t[0] ) ) );

      if j <> nil then begin
        Result := j.Get('exp', FDefaultExpiration);
      end;
    finally
      j.Free
    end;
  end;

  SetLength(t, 0);
end;

function TfrmViewMain.FieldsAdd(AName, AType, ASize, ADescription: string; ARequered: Boolean): Boolean;
// adiciona dados na stringGrid
begin
  if (AName='') or (AType='') or (ASize='') then Exit(False);

  if FFieldRow = 0 then begin
    FFieldRow := sgFields.RowCount;
    sgFields.RowCount := sgFields.RowCount + 1;
  end;

  sgFields.Cells[0, FFieldRow] := AName;
  sgFields.Cells[1, FFieldRow] := AType;
  sgFields.Cells[2, FFieldRow] := ASize;

  if ARequered then
    sgFields.Cells[3, FFieldRow] := 'yes'
  else
    sgFields.Cells[3, FFieldRow] := 'no';

  sgFields.Cells[4, FFieldRow] := ADescription;

  FFieldRow := 0;
  Result := True;
end;

function TfrmViewMain.FieldsToJson(): string;
// retorna os campos em formato json
var
  j: TJSONArray;
  i: Integer;
begin
  j := TJSONArray.Create;

  for i := 1 to sgFields.RowCount - 1 do begin
    j.Add( TJSONObject.Create([
                               'field_name', sgFields.Cells[0, i],
                               'field_type', sgFields.Cells[1, i],
                               'field_length', sgFields.Cells[2, i],
                               'field_required', (sgFields.Cells[3, i] = 'yes'),
                               'field_description', sgFields.Cells[4, i]
                               ])
         );
  end;

  Result := j.AsJSON;
end;

procedure TfrmViewMain.FieldsFromJson(AstrJson: string);
// carrega a stringGrid
var
  j: TJSONArray;
  obj: TJSONObject;
  i: Integer;
begin
  sgFields.RowCount := 1;
  FFieldRow := 0;

  try
    j := TJSONArray( GetJSON( AstrJson ) );

    if (j <> nil) then begin
      for i := 0 to j.Count - 1 do begin
        obj := TJSONObject( j.Objects[i] );

        FieldsAdd( obj.Get('field_name', ''),
                   obj.Get('field_type', ''),
                   obj.Get('field_length', ''),
                   obj.Get('field_description', ''),
                   obj.Get('field_required', false)
                 );
      end;

      sgFields.ClearSelections;
    end;
  finally
    j.Free;
  end;
end;

function TfrmViewMain.BodyFromFields(ADados: string; ABreakLine: Boolean): string;
// retorna dados para Post/Put, do StringGrid Fields para o Body para o request
var
  ar: TJSONArray;
  j, obj: TJSONObject;
  i: Integer;
begin
  Result := '';
  //edtReqBody.Text := '{'#13'"username": "admin",'#13'"password": "123"'#13'}';

  ar := TJSONArray( GetJSON( ADados ) );
  obj := TJSONObject.Create;

  try
    if ar <> nil then begin
      for i := 0 to ar.Count - 1 do begin
        j := TJSONObject( ar.Objects[i] );

        // Uses Math;
        // var x: Double
        // Writeln(x:0:2); // Displays x with 2 decimal places
        // s := Format('%.2f', [1.2345]); // Result: '1.23'
        // s := FloatToStrF(1.2345, ffFixed, 7, 2); // Result: '1.23'
        // x := RoundTo(1.23456, -2); // Result: 1.23
        // x := RoundTo(1234.56, 3);   // Result: 1000.0 (rounds to nearest thousand)

        if j <> nil then
          case j.Get('field_type', '') of
            'boolean':  obj.Add(j.Get('field_name', ''), True);
            'datetime': obj.Add(j.Get('field_name', ''), Format('%s', [DateToISO8601(now)]));
            'float':    obj.Add(j.Get('field_name', ''), 2.99);
            'integer':  obj.Add(j.Get('field_name', ''), 1);
            'string':   obj.Add(j.Get('field_name', ''), '');
          end;

      end; // for

      if ABreakLine then
        Result := obj.FormatJSON()
      else
        Result := obj.AsJSON;

      //  Result := Result.Replace(',', ','#13).Replace('{', '{'#13).Replace('}', #13'}');
    end; // if
  finally
    obj.Free;
    ar.Free;
  end;
end;

procedure TfrmViewMain.LimparCamposParams;
begin
  FParamRow := 0;
  btnParam_Adicionar.ImageIndex := 8;
  edtParam_Name.Clear;
  cboParam_Type.ItemIndex := 4;
  edtParam_Descricao.Clear;
end;

function TfrmViewMain.ParamsAdd(AName, AType, ADescription: string): Boolean;
// adiciona dados na stringGrid
begin
  if (AName='') or (AType='') then Exit(False);

  if FParamRow = 0 then begin
    FParamRow := sgParams.RowCount;
    sgParams.RowCount := sgParams.RowCount + 1;
  end;

  sgParams.Cells[0, FParamRow] := AName;
  sgParams.Cells[1, FParamRow] := AType;
  sgParams.Cells[2, FParamRow] := ADescription;

  FParamRow := 0;
  Result := True;
end;

function TfrmViewMain.ParamsToJson(): string;
// retorna os campos em formato json
var
  j: TJSONArray;
  i: Integer;
begin
  j := TJSONArray.Create;

  for i := 1 to sgParams.RowCount - 1 do begin
    j.Add( TJSONObject.Create([
                               'param_name', sgParams.Cells[0, i],
                               'param_type', sgParams.Cells[1, i],
                               'param_description', sgParams.Cells[2, i]
                               ])
         );
  end;

  Result := j.AsJSON;
end;

procedure TfrmViewMain.ParamsFromJson(AstrJson: string);
// carrega a stringGrid
var
  j: TJSONArray;
  obj: TJSONObject;
  i: Integer;
begin
  sgParams.RowCount := 1;
  FParamRow := 0;

  try
    j := TJSONArray( GetJSON( AstrJson ) );

    if (j <> nil) then begin
      for i := 0 to j.Count - 1 do begin
        obj := TJSONObject( j.Objects[i] );

        ParamsAdd( obj.Get('param_name', ''),
                   obj.Get('param_type', ''),
                   obj.Get('param_description', '')
                 );
      end;

      sgParams.ClearSelections;
    end;
  finally
    j.Free;
  end;
end;

procedure TfrmViewMain.ImportarAPI(APathJson: string);
// efetua a importação dos dados da api
var
  t: TUtilImportaAPI;
begin
  t := TUtilImportaAPI.Create;

  if t.ImportarAPI(APathJson) then begin
    ShowMessage('API importada com sucesso');
    CarregaTreeView;
  end
  else
    ShowMessage(t.GetErro);

  t.Free;
end;

procedure TfrmViewMain.PegaTodosOsCampos(ABreakLine: Boolean);
// Obtém todos os campos para o Body
var
  ep: TServiceEndpoint;
  sFields: string;
begin
  edtReqBody.Clear;
  if FApiId < 1 then exit;

  case UpperCase(Trim(cboReqMethods.Text)) of
    'GET', 'DELETE': Exit;
  end;

  ep := TServiceEndpoint.Create(FApiId);
  sFields := ep.GetFieldsFromPost(FApiId, Trim(edtReqGrupo.Text));
  ep.Free;

  if Trim(sFields) = '' then Exit;
  edtReqBody.Text := BodyFromFields(sFields, ABreakLine);
end;

function TfrmViewMain.ExtractFileNameFromDisposition(const ADisposition: string): string;
// obtém o nome do arquivo
var
  S: string;
  P: Integer;
begin
  Result := '';
  S := ADisposition;

  // RFC 5987 / RFC 6266
  P := Pos('filename*=', LowerCase(S));

  if P > 0 then
  begin
    Result := Copy(S, P + Length('filename*='), MaxInt);

    // remove UTF-8''
    P := Pos('''''', Result);

    if P > 0 then
      Result := Copy(Result, P + 2, MaxInt);

    Result := UrlDecode(Result);
    Exit;
  end;

  P := Pos('filename=', LowerCase(s));

  if P > 0 then
  begin
    Result := Copy(S, P + Length('filename='), MaxInt);
    Result := StringReplace(Result, '"', '', [rfReplaceAll]);
    Result := Trim(Result);
  end;
end;

function TfrmViewMain.UrlDecode(const S: string): string;
var
  I: Integer;
  Hex: string;
begin
  Result := '';
  I := 1;

  while I <= Length(S) do
  begin
    case S[I] of
      '%':
      begin
        if I + 2 <= Length(S) then
        begin
          Hex := '$' + Copy(S, I + 1, 2);
          Result := Result + Chr(StrToIntDef(Hex, Ord('?')));
          Inc(I, 3);
        end
        else
          Break;
      end;
      '+':
        begin
          Result := Result + ' ';
          Inc(I);
        end;
    else
      begin
        Result := Result + S[I];
        Inc(I);
      end;
    end;
  end;
end;

end.


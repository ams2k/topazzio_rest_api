unit Util.ImportaApi;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Controls, Dialogs;

type

  { TUtilImportaAPI }

  TUtilImportaAPI = class
  private
    FErro: string;
    public
      constructor Create;
      destructor Destroy; override;
      property GetErro: string read FErro;
      function ImportarAPI(const APathJsonAPI: string): Boolean;
  end;

implementation

uses
  fpjson, jsonparser, DateUtils,
  Service.Api, Service.Endpoint;

{ TUtilImportaAPI }

constructor TUtilImportaAPI.Create;
begin

end;

destructor TUtilImportaAPI.Destroy;
begin
  inherited Destroy;
end;

function TUtilImportaAPI.ImportarAPI(const APathJsonAPI: string): Boolean;
var
  fsJSONFile: TFileStream;
  api: TServiceApi;
  rt: TServiceEndpoint;
  jdata: TJSONData;
  japi, jobj: TJSONObject;
  jroutes: TJSONArray;
  idapi, i: Integer;
  s, lApiName, lHostRoot, lVersao: string;
begin
  FErro := '';
  idapi := 0;
  Result := False;

  if not FileExists(APathJsonAPI) then begin
    FErro := 'Arquivo não encontrado.';
    Exit;
  end;

  if (ExtractFileExt(APathJsonAPI.ToLower) <> '.json') then begin
    FErro := 'Arquivo em formato inválido, esperado .json';
    Exit;
  end;

  // lendo o arquivo .json
  fsJSONFile:= TFileStream.Create(APathJsonAPI, fmOpenRead or fmShareDenyWrite);

  try
    jdata := GetJSON( fsJSONFile );

    try
      if jdata.JSONType = jtObject then begin

        japi := TJSONObject( jdata );
        jroutes := japi.Arrays['routes'];

        lApiName  := japi.Get('apiname', '');
        lHostRoot := japi.Get('host_root', '');
        lVersao   := japi.Get('versao', '');

        if (lApiName = '') or (lHostRoot = '') or (lVersao = '') or (jroutes.Count < 1) then begin
          FErro := 'Não é um arquivo válido com dados da API e ROTAS';
        end
        else begin
          s := sLineBreak +
               lApiName + sLineBreak +
               lHostRoot + sLineBreak +
               lVersao + sLineBreak +
               '(' + IntToStr(jroutes.Count) + ' rotas)';
          if QuestionDlg('Atenção','Deseja importar esta API e suas Rotas ?' + s,
                         mtConfirmation, [mrYes, 'Sim', mrNo, 'Não', 'IsDefault'], '') <> mrYes then begin
            FErro := 'Importação cancelada';
          end;
        end;

        if FErro = '' then begin
          api := TServiceApi.Create;
          api.ApiName       := lApiName;
          api.HostRoot      := lHostRoot;
          api.Versao        := lVersao;
          api.Description   := japi.Get('description', '');
          api.Header_Texto1 := japi.Get('header_texto1', '');
          api.Header_Texto2 := japi.Get('header_texto2', '');
          api.Header_Texto3 := japi.Get('header_texto3', '');
          api.Footer_Texto1 := japi.Get('footer_texto1', '');
          api.Footer_Texto2 := japi.Get('footer_texto2', '');
          api.BasicUsername := japi.Get('basic_username', '');
          api.BasicPassword := japi.Get('basic_password', '');
          api.Token         := japi.Get('token', '');

          if api.Salvar(0) then begin
            idapi := api.IdApi;

            for i := 0 to jroutes.Count-1 do begin
              jobj := TJSONObject( jroutes.Objects[i] );

              if jobj <> nil then begin
                rt := TServiceEndpoint.Create( idapi );
                rt.Group       := jobj.Get('rtgroup','');
                rt.Method      := jobj.Get('method','');
                rt.Prefix      := jobj.Get('prefix','');
                rt.Route       := jobj.Get('route','');
                rt.AuthMode    := jobj.Get('authmode','');
                rt.ContentType := jobj.Get('contenttype','');
                rt.Headers     := TJSONArray(jobj.Arrays['headers']).AsJSON; //json array
                rt.Parameters  := TJSONArray(jobj.Arrays['parameters']).AsJSON; //json array
                rt.TableFields := TJSONArray(jobj.Arrays['table_fields']).AsJSON; //json array
                rt.Body        := jobj.Get('body','');
                rt.Description := jobj.Get('description','');

                if rt.Salvar(0) then begin
                  rt.SalvarResponseOK(rt.IdEndpoint,
                                      jobj.Get('response_ok_code',''),
                                      jobj.Get('response_ok_type',''),
                                      jobj.Get('response_ok_text','')
                                     );

                  rt.SalvarResponseNeg(rt.IdEndpoint,
                                       jobj.Get('response_neg_code',''),
                                       jobj.Get('response_neg_type',''),
                                       jobj.Get('response_neg_text','')
                                      );
                end;

                rt.Free;
              end;

            end; // for jroutes

            Result := True;
          end
          else begin
            FErro := api.MensagemErro;
          end;

          api.Free;
        end;
      end
      else begin
         FErro := 'Não é um arquivo JSON válido';
      end;
    finally
      jdata.Free;
    end;
  finally
    fsJSONFile.Free;
  end;
 end;

end.


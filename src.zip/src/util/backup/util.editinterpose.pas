unit Util.EditInterpose;

// modificação no TEdit e TMemo para alterar a cor de fundo quando obter foco

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, StdCtrls, Graphics;

type

  { TEdit }

  TEdit = class(StdCtrls.TEdit)
  private
    FChangeBackColor: Boolean;
  protected
    procedure DoEnter; override;
    procedure DoExit; override;
  published
    property ChangeBackColor: Boolean read FChangeBackColor write FChangeBackColor;
  end;

  { TMemo }

  TMemo = class(StdCtrls.TMemo)
  protected
    procedure DoEnter; override;
    procedure DoExit; override;
  end;

implementation

{ TEdit }

procedure TEdit.DoEnter;
begin
  if Enabled or not ReadOnly then
    Color := $00CCF9FA;
  inherited DoEnter;
end;

procedure TEdit.DoExit;
begin
  Color := clDefault;
  inherited DoExit;
end;

{ TMemo }

procedure TMemo.DoEnter;
begin
  if Enabled or not ReadOnly then
    Color := $00CCF9FA;
  inherited DoEnter;
end;

procedure TMemo.DoExit;
begin
  Color := clDefault;
  inherited DoExit;
end;

end.


unit Util.ExportaApi;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, fpjson, jsonparser, DateUtils;

type

  { TUtilExportaAPI }

  TUtilExportaAPI = class
    private
      FErro: string;
      function SalvaArquivo(AApiName, AJson: string): Boolean;
    public
      constructor Create;
      destructor Destroy; override;
      property GetErro: string read FErro;
      function ExportarAPI(const APathJsonAPI: string; AIdApi: Integer): Boolean;
  end;

implementation

uses
  ZDataset,
  Service.Api, Service.Endpoint;

{ TUtilExportaAPI }

constructor TUtilExportaAPI.Create;
begin

end;

destructor TUtilExportaAPI.Destroy;
begin
  inherited Destroy;
end;

function TUtilExportaAPI.ExportarAPI(const APathJsonAPI: string; AIdApi: Integer): Boolean;
// gera o json da api indicada
var
  rotas: TZQuery;
  api: TServiceApi;
  rt: TServiceEndpoint;
  japi, jobj: TJSONObject;
  jroutes: TJSONArray;
  s: string;
begin
  FErro := '';
  Result := False;

  api := TServiceApi.Create;

  if api.Ler(AIdApi) then
  begin
    japi := TJSONObject.Create;

    japi.Add('apiname', api.ApiName);
    japi.Add('host_root', api.HostRoot);
    japi.Add('versao', api.Versao);
    japi.Add('basic_username', api.BasicUsername);
    japi.Add('basic_password', api.BasicPassword);
    japi.Add('token', ''); //api.Token
    japi.Add('description', api.Description);
    japi.Add('header_texto1', api.Header_Texto1);
    japi.Add('header_texto2', api.Header_Texto2);
    japi.Add('header_texto3', api.Header_Texto3);
    japi.Add('footer_texto1', api.Footer_Texto1);
    japi.Add('footer_texto2', api.Footer_Texto2);

    // rotas

    jroutes := TJSONArray.Create;

    rt := TServiceEndpoint.Create(AIdApi);
    rotas := rt.qryEndPointsExport(AIdApi);

    while not rotas.EOF do
    begin
      jobj := TJSONObject.Create;

      jobj.Add('rtgroup', rotas.FieldByName('rtgroup').AsString);
      jobj.Add('method', rotas.FieldByName('method').AsString);
      jobj.Add('prefix', rotas.FieldByName('prefix').AsString);
      jobj.Add('route', rotas.FieldByName('route').AsString);
      jobj.Add('authmode', rotas.FieldByName('authmode').AsString);
      jobj.Add('contenttype', rotas.FieldByName('contenttype').AsString);
      jobj.Add('table_fields', GetJSON(rotas.FieldByName('table_fields').AsString));
      jobj.Add('headers', GetJSON(rotas.FieldByName('headers').AsString));
      jobj.Add('parameters', GetJSON(rotas.FieldByName('parameters').AsString));

      // body
      s := Trim(rotas.FieldByName('body').AsString);

      if s <> '' then
        jobj.Add('body', GetJSON(s))
      else
        jobj.Add('body', TJSONObject.Create);

      // description
      jobj.Add('description', Trim(rotas.FieldByName('description').AsString));

      // response ok
      jobj.Add('response_ok_code', Trim(rotas.FieldByName('response_ok_code').AsString));
      jobj.Add('response_ok_type', Trim(rotas.FieldByName('response_ok_type').AsString));

      s := Trim(rotas.FieldByName('response_ok_text').AsString).Replace(sLineBreak, '');
      if (s = '{}') or (s = '[]') then s := '';

      if s.StartsWith('{') or s.StartsWith('[') then
        jobj.Add('response_ok_text', GetJSON(s))
      else
        jobj.Add('response_ok_text', s);

      // response negativo
      jobj.Add('response_neg_code', Trim(rotas.FieldByName('response_neg_code').AsString));
      jobj.Add('response_neg_type', Trim(rotas.FieldByName('response_neg_type').AsString));

      s := Trim(rotas.FieldByName('response_neg_text').AsString).Replace(sLineBreak, '');
      if (s = '{}') or (s = '[]') then s := '';

      if s.StartsWith('{') or s.StartsWith('[') then
        jobj.Add('response_neg_text', GetJSON(s))
      else
        jobj.Add('response_neg_text', s);


      jroutes.Add(jobj);

      rotas.Next;
    end;

    rotas.Close;
    FreeAndNil(rotas);
    rt.Free;

    // salva no arquivo JSON

    japi.Add('routes', jroutes);

    // ajustes
    //s := japi.FormatJSON(); // japi.AsJSON();

    Result := SalvaArquivo(APathJsonAPI, japi.FormatJSON());

    japi.Free;
  end
  else
    FErro := api.Memssagem;

  api.Free;
end;

function TUtilExportaAPI.SalvaArquivo(AApiName, AJson: string): Boolean;
var
  docFile: TextFile;
begin
  Result := False;

  // deleta o arquivo, se existir
  if FileExists(AApiName) then
     DeleteFile(AApiName);

  // Define o arquivo a ser criado
  AssignFile(docFile, AApiName);
  // Use exceptions to catch errors (this is the default so not absolutely requried)
  {$I+}

  try
    // Cria/Sobrescreve o arquivo
    Rewrite(docFile);

    // salva o conteúdo
    WriteLn(docFile, AJson);

    // fecha o arquivo
    CloseFile(docFile);

    Result := True;
  except
    on E: EInOutError do
       FErro := 'Erro no manuseio do arquivo json.' + sLineBreak + E.ClassName + sLineBreak + E.Message;
  end;
end;

end.


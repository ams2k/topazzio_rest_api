unit Util.CNPJValidacao;

{$mode ObjFPC}{$H+}

interface

function IsValidCNPJ(cnpj: string): boolean;
function CalculaDV(baseCnpj: string): string;

implementation

uses
  SysUtils, StrUtils, RegExpr;

const
  TAMANHO_CNPJ_SEM_DV = 12;
  REGEX_CARACTERES_FORMATACAO = '[./-]';
  REGEX_FORMACAO_BASE_CNPJ = '[A-Z\d]{12}';
  REGEX_FORMACAO_DV = '[\d]{2}';
  REGEX_VALOR_ZERADO = '^[0]+$';
  VALOR_BASE = Ord('0');
  PESOS_DV: array[0..12] of Integer = (6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2);

function RemoveCaracteresFormatacao(const cnpj: string): string;
begin
  Result := Trim(cnpj);
  Result := ReplaceRegExpr(REGEX_CARACTERES_FORMATACAO, Result, '', False);
end;

function IsCnpjFormacaoValidaSemDV(cnpj: string): boolean;
var
  i: Integer;
begin
  Result := False;
  cnpj := RightStr('00000000000000' + cnpj, 14);
  cnpj := cnpj.ToUpper;

  // Verifica se todos os caracteres são dígito ou letra maiúscula
  for i := 1 to 12 do
    if not (cnpj[i] in ['0'..'9', 'A'..'Z']) then Exit;

  // Verifica se não é todo zero
  Result := cnpj <> '000000000000';
end;

function IsCnpjFormacaoValidaComDV(cnpj: string): boolean;
var
  i: Integer;
begin
  Result := False;
  cnpj := RightStr('00000000000000' + cnpj, 14);
  cnpj := cnpj.ToUpper;

  // Verifica se os 12 primeiros são alfanuméricos e os 2 últimos são dígitos
  for i := 1 to 12 do
    if not (cnpj[i] in ['0'..'9', 'A'..'Z']) then Exit;

  for i := 13 to 14 do
    if not (cnpj[i] in ['0'..'9']) then Exit;

  // Verifica se não é todo zero
  Result := cnpj <> '00000000000000';
end;

function CalculaDigito(const cnpj: string): Integer;
var
  i, soma, valorCaracter: Integer;
begin
  soma := 0;
  for i := Length(cnpj) downto 1 do
  begin
    valorCaracter := Ord(cnpj[i]) - VALOR_BASE;
    soma := soma + valorCaracter * PESOS_DV[High(PESOS_DV) - Length(cnpj) + i];
  end;
  if (soma mod 11) < 2 then
    Result := 0
  else
    Result := 11 - (soma mod 11);
end;

function CalculaDV(const baseCnpj: string): string;
var
  baseLimpa, dv1, dv2: string;
begin
  if baseCnpj = '' then
    raise Exception.Create('CNPJ não pode ser vazio para cálculo do DV');

  baseLimpa := RemoveCaracteresFormatacao(baseCnpj);

  if not IsCnpjFormacaoValidaSemDV(baseLimpa) then
    raise Exception.CreateFmt('Cnpj %s não é válido para o cálculo do DV', [baseCnpj]);

  dv1 := IntToStr(CalculaDigito(baseLimpa));
  dv2 := IntToStr(CalculaDigito(baseLimpa + dv1));

  Result := dv1 + dv2;
end;

function IsValidCNPJ(const cnpj: string): boolean;
var
  cnpjLimpo, dvInformado, dvCalculado: string;
begin
  Result := False;

  if cnpj = '' then
    Exit;

  cnpjLimpo := RemoveCaracteresFormatacao(cnpj);

  if IsCnpjFormacaoValidaComDV(cnpjLimpo) then
  begin
    dvInformado := Copy(cnpjLimpo, TAMANHO_CNPJ_SEM_DV + 1, 2);
    dvCalculado := CalculaDV(Copy(cnpjLimpo, 1, TAMANHO_CNPJ_SEM_DV));
    Result := dvCalculado = dvInformado;
  end;
end;

end.


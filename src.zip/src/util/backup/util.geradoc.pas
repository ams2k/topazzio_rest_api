unit Util.GeraDoc;

// gera a documentação da API indicada
//
// https://www.w3schools.com/css/css_table_style.asp
// Access-Control-Allow-Origin: *
// https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS#the_http_response_headers

{$mode ObjFPC}{$H+}

interface

uses
   Classes, SysUtils, StrUtils, ExtCtrls,
   DB, SQLDB, ZDataset, fpjson, DateUtils,
   Service.Api, Service.Endpoint;

type

  { TUtilGeraDoc }

  TUtilGeraDoc = class
  private
    FDocumentoPath: String;
    FErroMsg: String;
    FParamtersCount: Integer;
    { header e footer do documento da api}
    function BodyFromFields(AStrJson: string; ABreakLine: Boolean): string;
    procedure CriarPasta(APasta: String);
    function GetDocHeader(api: TServiceAPI): String;
    function GetDocFooter(api: TServiceAPI): String;
    function GetDocRotaFields(AIdApi, AIdGroup: Integer; ARouteGroup: String): String;
    { rotas }
    function GetDocRotaHeader(qry: TZQuery): String;
    function GetDocRotaEndPoint(qry: TZQuery; AHost, APrefixo: String): String;
    function GetDocRotaFooter(qry: TZQuery): String;
    function GetResposta(ACode, AContentType, AResponse: string): String;
    function GetDetalhes(AOcultar: Boolean; ATitulo, AValor: String): String;
    function GetParametros(AOcultar: Boolean; qry: TZQuery): String;
  public
    function GeraDocumento(AIdApi: Integer; ALogoDoc: TImage): Boolean;
    property GetErroMsg: String read FErroMsg;
    property GetDocumentoPath: String read FDocumentoPath;
  end;

implementation

{ TUtilApiDoc }

function TUtilGeraDoc.GeraDocumento(AIdApi: Integer; ALogoDoc: TImage): Boolean;
// gera a documentação da api indicada
var
  api: TServiceApi;
  rota: TServiceEndpoint;
  qryRotas: TZQuery;
  endpoint: TServiceEndpoint;
  qryEndPoint: TZQuery;
  docFile: TextFile;
  FPastaRaiz, docPathNome, lFields, lVersao: String;
begin
  FErroMsg := '';
  FDocumentoPath := '';
  Result := False;

  api := TServiceAPI.Create;

  if api.Ler(AIdApi) then begin
    // cria a pasta raiz da api
    FPastaRaiz := ExtractFileDir( ParamStr(0) ) + PathDelim;
    CriarPasta(FPastaRaiz);

    // pasta do documento
    lVersao := '_' + api.Versao.Replace('/', '_');
    if lVersao = '_' then lVersao := '';
    lVersao := lVersao.Replace('__', '_');
    FPastaRaiz := FPastaRaiz + api.ApiName.Replace(' ', '_') + lVersao + PathDelim;
    CriarPasta(FPastaRaiz);

    // informações da api indicada
    docPathNome := FPastaRaiz + 'doc.html';

    // deleta o arquivo, se existir
    if FileExists(docPathNome) then
       DeleteFile(docPathNome);

    // Define o arquivo a ser criado
    AssignFile(docFile, docPathNome);
    // Use exceptions to catch errors (this is the default so not absolutely requried)
    {$I+}

    try
      // Cria/Sobrescreve o arquivo
      Rewrite(docFile);

      // cria o cabeçalho do documento
      WriteLn(docFile, GetDocHeader(api));

      // obtém as rotas
      rota := TServiceEndPoint.Create(AIdApi);
      qryRotas := rota.qryGrupoRotas(AIdApi);

      while not qryRotas.EOF do begin
        // pega a lista de endpoints de cada rota
        endpoint := TServiceEndPoint.Create(AIdApi);
        qryEndPoint := endpoint.qryEndPoints(AIdApi, qryRotas.FieldByName('rtgroup').AsString);

        if qryEndPoint.RecordCount > 0 then begin
          // header da rota raiz
          WriteLn(docFile, GetDocRotaHeader(qryEndPoint));

          // Fields da tabela para o método POST
          lFields := GetDocRotaFields(api.IdApi, qryRotas.FieldByName('idgroup').AsInteger, qryRotas.FieldByName('rtgroup').AsString);
          if Length(lFields) > 0 then
            WriteLn(docFile, lFields);

          while not qryEndPoint.EOF do begin
            // endpoint
            WriteLn(docFile, GetDocRotaEndPoint( qryEndPoint, api.HostRoot, api.Versao));

            // próximo endpoint
            qryEndPoint.Next;
          end;

          // footer da rota raiz
          WriteLn(docFile, GetDocRotaFooter(qryRotas));
        end;

        qryEndPoint.Close;
        FreeAndNil(qryEndPoint);
        FreeAndNil(endpoint);

        // próxima rota raiz
        qryRotas.Next;
      end;

      qryRotas.Close;
      FreeAndNil(qryRotas);
      FreeAndNil(rota);

      // cria o footer do documento
      WriteLn(docFile, GetDocFooter(api));

      // fecha o arquivo
      CloseFile(docFile);

      // informações finais
      FDocumentoPath := docPathNome;

      if Assigned(ALogoDoc) then
        ALogoDoc.Picture.SaveToFile(FPastaRaiz + 'apidoc.png');

      Result := True;
    except
      on E: EInOutError do
       FErroMsg := 'Erro no manuseio do arquivo.' + sLineBreak + E.ClassName + sLineBreak + E.Message;
    end;
  end else
    FErroMsg := api.MensagemErro;

  FreeAndNil(api);
end;

procedure TUtilGeraDoc.CriarPasta(APasta: String);
// cria pastas
begin
  APasta := APasta.Replace(PathDelim + PathDelim, PathDelim);// remove (//) barras duplas

  try
    if not DirectoryExists(APasta) then
      CreateDir(APasta);
  except
  end;
end;

function TUtilGeraDoc.GetDocHeader(api: TServiceAPI): String;
// retorna o cabeçalho do documento da api
begin
  Result := '';
  Result := Result + '<!DOCTYPE html> ' + sLineBreak;
  Result := Result + '<html lang="pt-br"> ' + sLineBreak;
  Result := Result + '<head> ' + sLineBreak;
  Result := Result + '    <meta charset="UTF-8"> ' + sLineBreak;
  Result := Result + '    <meta name="viewport" content="width=device-width, initial-scale=1.0"> ' + sLineBreak;
  Result := Result + '    <title>' + api.ApiName + '</title> ' + sLineBreak;
  Result := Result + '    <style> ' + sLineBreak;
  Result := Result + '        body {  ' + sLineBreak;
  Result := Result + '            font-family: ''Arial'', sans-serif;  ' + sLineBreak;
  Result := Result + '            background-color: #f8f9fa;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        tr:hover {background-color: #fffff0;}' + sLineBreak;
  Result := Result + '        .param1 { ' + sLineBreak;
  Result := Result + '            width: 100px; ' + sLineBreak;
  Result := Result + '        		margin-left: 5px; ' + sLineBreak;
  Result := Result + '            background-color: #fff;  ' + sLineBreak;
  Result := Result + '            padding: 5px; ' + sLineBreak;
  Result := Result + '            border-radius: 5px; ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '        .param2 { ' + sLineBreak;
  Result := Result + '            width: 100px; ' + sLineBreak;
  Result := Result + '            margin-left: 5px; ' + sLineBreak;
  Result := Result + '            background-color: #fff;  ' + sLineBreak;
  Result := Result + '            padding: 5px; ' + sLineBreak;
  Result := Result + '            border-radius: 5px;   ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .param3 { ' + sLineBreak;
  Result := Result + '            margin-left: 5px; ' + sLineBreak;
  Result := Result + '            background-color: #fff;  ' + sLineBreak;
  Result := Result + '            padding: 5px; ' + sLineBreak;
  Result := Result + '            border-radius: 5px; ' + sLineBreak;
  Result := Result + '        }     ' + sLineBreak;
  Result := Result + '        .container {  ' + sLineBreak;
  Result := Result + '            margin-top: 8px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        h1, h2 {  ' + sLineBreak;
  Result := Result + '            color: #343a40;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        i { color: #444; }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .toggle-symbol { font-weight: bold; }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .container-one {  ' + sLineBreak;
  Result := Result + '            width: 70px;  ' + sLineBreak;
  Result := Result + '            height: 90%;  ' + sLineBreak;
  Result := Result + '            float: left;  ' + sLineBreak;
  Result := Result + '            align-content: center;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            text-align: center;  ' + sLineBreak;
  Result := Result + '            color: #fff;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .container-two {  ' + sLineBreak;
  Result := Result + '            margin-left: 90px;              ' + sLineBreak;
  Result := Result + '            height: 90%;  ' + sLineBreak;
  Result := Result + '            align-content: center;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .container-one-post {  ' + sLineBreak;
  Result := Result + '            background-color: #49cc90;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-get {  ' + sLineBreak;
  Result := Result + '            background-color: #61affe;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-put {  ' + sLineBreak;
  Result := Result + '            background-color: #fca130;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-delete {  ' + sLineBreak;
  Result := Result + '            background-color: #f93e3e;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-patch {  ' + sLineBreak;
  Result := Result + '            background-color: #dbb735;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-post {  ' + sLineBreak;
  Result := Result + '            background-color: #e8f6f0;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #49cc90;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-get {  ' + sLineBreak;
  Result := Result + '            background-color: #ebf3fb;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #61affe;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-put {  ' + sLineBreak;
  Result := Result + '            background-color: #fbf1e6;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #fca130;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-delete {  ' + sLineBreak;
  Result := Result + '            background-color: #fae7e7;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #f93e3e;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-patch {  ' + sLineBreak;
  Result := Result + '            background-color: #fdfcdb;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #dbb735;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .card-container {  ' + sLineBreak;
  Result := Result + '            width: 100%;  ' + sLineBreak;
  Result := Result + '            border: none;  ' + sLineBreak;
  Result := Result + '            background-color: #ffc16b;   ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '            margin-bottom: 8px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .card-container-title {  ' + sLineBreak;
  Result := Result + '        	  padding: 5px 5px 5px 5px;  ' + sLineBreak;
  Result := Result + '            color: #41444e;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            vertical-align: middle;  ' + sLineBreak;
  Result := Result + '            border-bottom: 1px solid #888;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '                ' + sLineBreak;
  Result := Result + '        .card-container-body {  ' + sLineBreak;
  Result := Result + '        	  padding: 8px 5px 2px 5px;  ' + sLineBreak;
  Result := Result + '            background-color: #eee;  ' + sLineBreak;
  Result := Result + '            display: all;  ' + sLineBreak;
  Result := Result + '            transition: all 0.3s ease-in-out;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '	    .card {  ' + sLineBreak;
  Result := Result + '            margin: 4px 0px 4px 0px; //Top Right Bothon Left  ' + sLineBreak;
  Result := Result + '            border: none;  ' + sLineBreak;
  Result := Result + '            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);  ' + sLineBreak;
  Result := Result + '            border-radius: 10px;  ' + sLineBreak;
  Result := Result + '            padding-bottom: 2px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .card-header {  ' + sLineBreak;
  Result := Result + '            border-radius: 7px 7px 7px 7px;  ' + sLineBreak;
  Result := Result + '            padding: 4px 4px 2px 4px;  ' + sLineBreak;
  Result := Result + '            font-size: 18px;  ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '            height: 30px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-header-open {  ' + sLineBreak;
  Result := Result + '            border-radius: 7px 7px 0 0;  ' + sLineBreak;
  Result := Result + '            padding: 4px 4px 2px 4px;  ' + sLineBreak;
  Result := Result + '            font-size: 18px;  ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '            height: 30px;  ' + sLineBreak;
  Result := Result + '            border-bottom: 0px; ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .card-body {  ' + sLineBreak;
  Result := Result + '            padding: 5px 10px 10px 10px;  ' + sLineBreak;
  Result := Result + '            background-color: #ffffff;  ' + sLineBreak;
  Result := Result + '            border-radius: 0 0 10px 10px;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            display: none;  ' + sLineBreak;
  Result := Result + '            transition: all 0.3s ease-in-out;  ' + sLineBreak;
  Result := Result + '            cursor: default;  ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .card-body-post {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #49cc90;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-get {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #61affe;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-put {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #fca130;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-delete {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #f93e3e;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-patch {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #dbb735;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '     .card-container-title:hover {  ' + sLineBreak;
  Result := Result + '            background-color: rgba(255, 170, 0, 0.5);  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .verb-post:hover { background-color: #cbf6e2; }  ' + sLineBreak;
  Result := Result + '        .verb-get:hover { background-color: #d1eafb; }  ' + sLineBreak;
  Result := Result + '        .verb-put:hover { background-color: #fbe5cd; }  ' + sLineBreak;
  Result := Result + '        .verb-delete:hover { background-color: #fad4d3; }  ' + sLineBreak;
  Result := Result + '        .verb-patch:hover { background-color: #fdfbb7; }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        pre {  ' + sLineBreak;
  Result := Result + '            background-color: #f1f3f5;  ' + sLineBreak;
  Result := Result + '            padding: 6px;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            font-size: 12px;  ' + sLineBreak;
  Result := Result + '            overflow-x: auto;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .table th {  ' + sLineBreak;
  Result := Result + '            background-color: #f8f9fa;  ' + sLineBreak;
  Result := Result + '            color: #495057;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        button {  ' + sLineBreak;
  Result := Result + '            background-color: #ffffff;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #ccc;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            padding: 5px 10px;  ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        button:hover {  ' + sLineBreak;
  Result := Result + '            background-color: #f1f3f5;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        header {  ' + sLineBreak;
  Result := Result + '        	  height: 140px; ' + sLineBreak;
  Result := Result + '           margin-top: 5px;  ' + sLineBreak;
  Result := Result + '           padding: 10px;  ' + sLineBreak;
  Result := Result + '           background-color: #343a40;  ' + sLineBreak;
  Result := Result + '           color: white;  ' + sLineBreak;
  Result := Result + '           text-align: center;  ' + sLineBreak;
  Result := Result + '           border-radius: 5px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        header h1 {  ' + sLineBreak;
  Result := Result + '            text-decoration: none;  ' + sLineBreak;
  Result := Result + '            color: white;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        footer {  ' + sLineBreak;
  Result := Result + '            margin-top: 50px;  ' + sLineBreak;
  Result := Result + '            padding: 10px;  ' + sLineBreak;
  Result := Result + '            background-color: #343a40;  ' + sLineBreak;
  Result := Result + '            color: white;  ' + sLineBreak;
  Result := Result + '            text-align: center;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        footer a {  ' + sLineBreak;
  Result := Result + '            color: #fff;  ' + sLineBreak;
  Result := Result + '            text-decoration: none;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        footer a:hover {  ' + sLineBreak;
  Result := Result + '            text-decoration: underline;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .mb-4 {margin-bottom:1.1rem!important}  ' + sLineBreak;
  Result := Result + '        .linha {  ' + sLineBreak;
  Result := Result + '           display: flex;  ' + sLineBreak;
  Result := Result + '           justify-content: space-between;  ' + sLineBreak;
  Result := Result + '           align-items: center;  ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '        .linha a {  ' + sLineBreak;
  Result := Result + '    	  text-decoration: none;  ' + sLineBreak;
  Result := Result + '    	  margin-left: auto;  ' + sLineBreak;
  Result := Result + '	      }  ' + sLineBreak;
  Result := Result + '	   div { ' + sLineBreak;
  Result := Result + '    		display: block; ' + sLineBreak;
  Result := Result + '    		unicode-bidi: isolate; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		code { ' + sLineBreak;
  Result := Result + '         color: #444; ' + sLineBreak;
  Result := Result + '    		background-color: #f5f5f5; ' + sLineBreak;
  Result := Result + '         font: monospace, Consolas,"courier new"; ' + sLineBreak;
  Result := Result + '         font-size: 12px; ' + sLineBreak;
  Result := Result + '    		padding: 1px 4px; ' + sLineBreak;
  Result := Result + '    		border: 1px solid #cfcfcf; ' + sLineBreak;
  Result := Result + '         border-radius: 3px; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition { ' + sLineBreak;
  Result := Result + '    		margin-top: 12px; ' + sLineBreak;
  Result := Result + '    		margin-bottom: 12px; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .uri { ' + sLineBreak;
  Result := Result + '    		word-break: break-all; ' + sLineBreak;
  Result := Result + '    		word-wrap: break-word; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .hostname { ' + sLineBreak;
  Result := Result + '    		opacity: .6; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.get { ' + sLineBreak;
  Result := Result + '    		color: #61affe; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.post { ' + sLineBreak;
  Result := Result + '    		color: #49cc90; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.put { ' + sLineBreak;
  Result := Result + '    		color: #fca130; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.delete { ' + sLineBreak;
  Result := Result + '    		color: #f93e3e; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.patch { ' + sLineBreak;
  Result := Result + '    		color: #dbb735; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method { ' + sLineBreak;
  Result := Result + '    		font-weight: bold; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.name { ' + sLineBreak;
  Result := Result + '    		float: right; ' + sLineBreak;
  Result := Result + '    		font-weight: normal; ' + sLineBreak;
  Result := Result + '    		padding: 6px 0; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.collapse-button { ' + sLineBreak;
  Result := Result + '    		float: right; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.collapse-button .close { ' + sLineBreak;
  Result := Result + '    		display: none; ' + sLineBreak;
  Result := Result + '    		color: #428bca; ' + sLineBreak;
  Result := Result + '    		cursor: pointer; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.collapse-button .open { ' + sLineBreak;
  Result := Result + '    		color: #428bca; ' + sLineBreak;
  Result := Result + '    		cursor: pointer; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '        .table-container-title {  ' + sLineBreak;
  Result := Result + '            padding: 5px 5px 5px 5px;  ' + sLineBreak;
  Result := Result + '            color: #041444e;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            vertical-align: middle;   ' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-container {' + sLineBreak;
  Result := Result + '            display: flex;' + sLineBreak;
  Result := Result + '            flex-direction: column;' + sLineBreak;
  Result := Result + '            border: 1px solid #ccc;' + sLineBreak;
  Result := Result + '            border-radius: 8px;' + sLineBreak;
  Result := Result + '            overflow: hidden;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-row {' + sLineBreak;
  Result := Result + '            display: flex;' + sLineBreak;
  Result := Result + '            border-bottom: 1px solid #ccc;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-row:first-child {' + sLineBreak;
  Result := Result + '            background-color: #f1f1f1;' + sLineBreak;
  Result := Result + '            font-weight: bold;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-cell {' + sLineBreak;
  Result := Result + '            flex: 1;' + sLineBreak;
  Result := Result + '            padding: 10px;' + sLineBreak;
  Result := Result + '            text-align: left;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-cell:not(:last-child) {' + sLineBreak;
  Result := Result + '            border-right: 1px solid #ccc;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '    </style> ' + sLineBreak;
  Result := Result + '</head> ' + sLineBreak;
  Result := Result + '<body> ' + sLineBreak;
  Result := Result + '    <div class="container"> ' + sLineBreak;
  Result := Result + '        <header class="mb-4"> ' + sLineBreak;
  Result := Result + '           <div class="container-one" style="height:140px; vertical-align:middle;"> ' + sLineBreak;

  if Trim(api.Url_Logo) <> '' then
     Result := Result + '             <img src="'+ api.Url_Logo + '" width="128" height="128" border="0" alt="Logo">' + sLineBreak;

  Result := Result + '           </div>' + sLineBreak;
  Result := Result + '           <div class="container-two">' + sLineBreak;
  Result := Result + '             <h1>' + api.Header_Texto1 + '</h1> ' + sLineBreak;
  Result := Result + '             <p>' + api.Header_Texto2 + '</p> ' + sLineBreak;
  Result := Result + '             <p>' + api.Header_Texto3 + '</p> ' + sLineBreak;
  Result := Result + '           </div>' + sLineBreak;
  Result := Result + '        </header> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <section id="overview"> ' + sLineBreak;

  if Trim(api.Description) <> '' then begin
    Result := Result + '            <h2>Visão Geral</h2> ' + sLineBreak;
    Result := Result + '            <p><font style="font-size:14px;">' + api.Description + '</font></p> ' + sLineBreak;
  end;

  Result := Result + '        </section> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <section id="endpoints"> ' + sLineBreak;
  Result := Result + '            <div class="linha">' + sLineBreak;
  Result := Result + '    	    <h2>Endpoints da API</h2> ' + sLineBreak;
  Result := Result + '    	    <a href="#" onclick="minimizarRotas()" style="font-size: 12px;">Retrair tudo</a>&nbsp;&nbsp; ' + sLineBreak;
  Result := Result + '		  </div> ' + sLineBreak;
  Result := Result + '            <hr style="border: 1px solid #a0a0a0;"> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocFooter(api: TServiceAPI): String;
// retorna o rodape do documento da api
begin
  Result := '';
  Result := Result + ' ' + sLineBreak;
  Result := Result + '          <hr style="border: 1px solid #a0a0a0;"> ' + sLineBreak;
  Result := Result + '        </section> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <section id="errors" style="font-size: 10px;"> ' + sLineBreak;
  Result := Result + '            <h3>Repostas mais comuns (StatusCode)</h3> ' + sLineBreak;
  Result := Result + '            <table class="table"> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td><b>Código</b></td> ' + sLineBreak;
  Result := Result + '               <td width="20"></td>' + sLineBreak;
  Result := Result + '               <td><b>Mensagem</b></td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">200</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>OK</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">201</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Created</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">202</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Accepted</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">400</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Bad Request</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">401</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Unauthorized</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">403</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Forbidden</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">404</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Not Found</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">500</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Internal Server Error</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '            </table> ' + sLineBreak;
  Result := Result + '        </section>' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <footer> ' + sLineBreak;
  Result := Result + '            <p>' + api.Footer_Texto1 + '</p> ' + sLineBreak;

  if Trim(api.Footer_Texto2) <> '' then
     Result := Result + '            <p>' + api.Footer_Texto2 + '</p> ' + sLineBreak;

  Result := Result + '        </footer> ' + sLineBreak;
  Result := Result + '    </div> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '     ' + sLineBreak;
  Result := Result + '    <script> ' + sLineBreak;
  Result := Result + '        function toggleVisibility(id) { ' + sLineBreak;
  Result := Result + '            var element = document.getElementById(id); ' + sLineBreak;
  Result := Result + '            var estiloAtual = window.getComputedStyle(element).display; ' + sLineBreak;
  Result := Result + '            var icon = document.getElementById("icon_" + id); ' + sLineBreak;
  Result := Result + '            var pai = document.getElementById("ch_" + id); ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '	 	  if (pai !== null){            ' + sLineBreak;
  Result := Result + '               var classe = pai.className; ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '               if (classe.indexOf("card-header-open") == 0) { ' + sLineBreak;
  Result := Result + '               	classe = classe.replace("card-header-open", "card-header"); ' + sLineBreak;
  Result := Result + '               } else if (classe.indexOf("card-header") == 0) { ' + sLineBreak;
  Result := Result + '            	classe = classe.replace("card-header", "card-header-open");            	 ' + sLineBreak;
  Result := Result + '               } ' + sLineBreak;
  Result := Result + '               document.getElementById("ch_" + id).className = classe; ' + sLineBreak;
  Result := Result + '            }             ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '            if (estiloAtual === "none") { ' + sLineBreak;
  Result := Result + '                element.style.display = "block"; ' + sLineBreak;
  Result := Result + '                icon.textContent = ''▼''; ' + sLineBreak;
  Result := Result + '            } else { ' + sLineBreak;
  Result := Result + '                element.style.display = "none"; ' + sLineBreak;
  Result := Result + '                icon.textContent = ''▶''; ' + sLineBreak;
  Result := Result + '            } ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '         ' + sLineBreak;
  Result := Result + '        function minimizarRotas() { ' + sLineBreak;
  Result := Result + '          document.querySelectorAll(''[id^="ep"]'').forEach(elemento => { ' + sLineBreak;
  Result := Result + '            elemento.style.display = ''none''; ' + sLineBreak;
  Result := Result + '            var icon = document.getElementById("icon_" + elemento.id); ' + sLineBreak;
  Result := Result + '            icon.textContent = ''▶''; ' + sLineBreak;
  Result := Result + '          }); ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '    </script> ' + sLineBreak;
  Result := Result + '</body> ' + sLineBreak;
  Result := Result + '</html> ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaEndPoint(qry: TZQuery; AHost, APrefixo: String): String;
// retorna o endpoint da rota do documento da api
var
  j: TJSONArray;
  obj: TJSONObject;
  sEndPoint, sToggle, sMetodo, sCssVerbo: String;
  sDescricao, sDescricao_longa, sAlteracoes: String;
  sHeader, sBody: String;
  ARota, sExemploHost, sExemploEndpoint: string;
  i: Integer;
begin
  // ajustes na rota
  ARota := Trim(qry.FieldByName('route').AsString);
  if LeftStr(ARota, 1) = '/' then ARota := ARota.Substring(1);
  if RightStr(ARota, 1) = '/' then ARota := ARota.Substring(0, ARota.Length-1);

  // Prefixo da api ( ex: /api/v2/ ) se foi informado (não obrigatório)
  APrefixo := Trim(APrefixo);

  while RightStr(APrefixo, 1) = '/' do
    APrefixo := LeftStr(APrefixo, Length(APrefixo)-1);

  if (APrefixo <> '') and (LeftStr(APrefixo, 1) <> '/') then APrefixo := '/' + APrefixo;

  // caminho completo do endpoint
  sEndPoint := StringReplace('/' + Trim(ARota), '//', '/', [rfReplaceAll]);
  while RightStr(sEndPoint, 1) = '/' do
    sEndPoint := LeftStr(sEndPoint, Length(sEndPoint)-1);

  // ID do objeto para a função toggleVisibility()
  sToggle := Trim(ARota) + IntToStr(qry.FieldByName('idep').AsInteger);

  //Verbo: POST, GET, PUT, DELETE
  sMetodo := Trim(qry.FieldByName('method').AsString);

  // para identificar a classe CSS
  sCssVerbo := LowerCase(sMetodo);

  // Exemplo de endpoint
  sExemploHost := qry.FieldByName('api_host_root').AsString;

  while RightStr(sExemploHost, 1) = '/' do
    sExemploHost := LeftStr(sExemploHost, Length(sExemploHost)-1);

  sExemploEndpoint := '<b>' + APrefixo + sEndPoint + '</b>';

  // Descrição breve e longa do endpoint
  sDescricao := 'Detalhes desta rota'; // + Trim(qry.FieldByName('description').AsString);
  sDescricao_longa := Trim(qry.FieldByName('description').AsString);
  if sDescricao_longa = '' then sDescricao_longa := sDescricao;

  // Alterações do endpoint
  sAlteracoes := '';
  //if Trim(qry.FieldByName('motivo_alteracao').AsString) <> '' then
  //  sAlteracoes := '<p><b>Última alteração</b> - ' + FormatDateTime('dd/mm/yyyy hh:nn:ss', qry.FieldByName('dt_modificado').AsDateTime) + '<br><font style="font-size:12px">' + qry.FieldByName('motivo_alteracao').AsString + '</font></p>';

  // Request - Header
  sHeader := '';
  if Trim(qry.FieldByName('authmode').AsString) <> 'NONE' then begin
     if sHeader <> '' then sHeader := sHeader + sLineBreak;
     if (qry.FieldByName('authmode').AsString = 'BASIC') then
       sHeader := sHeader + '<b>Authorization</b> ' + 'Basic username:password'
     else if (qry.FieldByName('authmode').AsString = 'JWT') then
       sHeader := sHeader + '<b>Authorization</b> ' + 'Bearer token_jwt';
  end;

  if (Trim(qry.FieldByName('headers').AsString) <> '') then begin
    try
      j := TJSONArray( GetJSON( qry.FieldByName('headers').AsString ) );

      if (j <> nil) and (j.Count > 0) then begin
        for i :=0 to j.Count -1 do begin
          obj := TJSONObject( j.Objects[i] );
          if obj <> nil then
            if sHeader <> '' then sHeader := sHeader + sLineBreak;
            sHeader := sHeader + '<b>' + obj.Get('key','') + '</b> ' + obj.Get('value','');
        end; // for
      end; // if
    finally
      j.Free;
    end;
  end;

  if sHeader = '' then sHeader := 'None';

  // Post Request - Body
  sBody := 'None';
  if (Trim(qry.FieldByName('table_fields').AsString) <> '') then
     sBody := BodyFromFields(qry.FieldByName('table_fields').AsString, True )
  else if (Trim(qry.FieldByName('body').AsString) <> '') then
     sBody := qry.FieldByName('body').AsString;

  Result := '' + sLineBreak;
  Result := Result + '<!-- ' + UpperCase(sMetodo) + ' ' + ARota + ' --> ' + sLineBreak;
  Result := Result + '            <div class="card"> ' + sLineBreak;
  Result := Result + '                <div class="card-header verb-'+ sCssVerbo + '" id="ch_' + sToggle + '" onclick="toggleVisibility(''' + sToggle + ''')"> ' + sLineBreak;
  Result := Result + '                    <div class="container-one container-one-' +sCssVerbo + '">' + UpperCase(sMetodo) + '</div> ' + sLineBreak;
  Result := Result + '                    <div class="container-two"><code class="uri">' + sEndPoint + '</code>&nbsp;&nbsp;&nbsp;<i class="name" style="font-size:12px;">' + sDescricao + '</i></div> ' + sLineBreak;
  Result := Result + '                </div> ' + sLineBreak;
  Result := Result + '                <div class="card-body card-body-' + sCssVerbo + '" id="'+ sToggle + '"> ' + sLineBreak;

  // exemplo de chamada do endpoint
  if sExemploEndpoint <> '' then begin
    Result := Result + '                  <div class="definition"> ' + sLineBreak;
    //Result := Result + '                     <b style="padding-bottom:8px;">Exemplo:</b>&nbsp;<br> ' + sLineBreak;
    Result := Result + '			   <span class="method ' +sCssVerbo + '">' + UpperCase(sMetodo) + '</span>&nbsp;  ' + sLineBreak;
    Result := Result + ' 			     <span class="uri"> ' + sLineBreak;
    Result := Result + '  		             <span class="hostname">' + sExemploHost + '</span>' + sExemploEndpoint + sLineBreak;
    Result := Result + ' 			   </span> ' + sLineBreak;
    Result := Result + '			</div> ' + sLineBreak;
  end;

  //Result := Result + '                  <p><strong style="padding-bottom:8px;">Descrição: </strong><br>' + sDescricao_longa + '</p> ' + sLineBreak;
  if Trim(sDescricao_longa) <> '' then
    Result := Result + '                  ' + sDescricao_longa + '<br>' + sLineBreak;

  Result := Result + sAlteracoes + sLineBreak;

  //----------------------------------------------
  // Requests
  Result := Result + '<br><div class="line" style="border-bottom: 1px solid #ddd; height:18px; margin: 10px 0px 5px 0px;"><p><b style="color: red; border: 1px solid #ddd; background-color:#efefef; border-radius: 5px;padding: 4px 4px 2px 4px;">Requests </b></p></div>' + sLineBreak;

  // tabela de requests
  Result := Result + '<table style="border: 1px solid #c0c0c0; width:100%" cellpadding=0 cellspacing=0>' + sLineBreak;
  Result := Result + '<tr><td style="text-align: center; background-color:#c0c0c0; width: 150px;">Nome</td><td style="background-color:#c0c0c0;">Descrição</td><td style="width:10px; background-color:#c0c0c0;">&nbsp;&nbsp;</td></tr>' + sLineBreak;

  // campos de parâmetros
  FParamtersCount := 0;
  Result := Result + GetDetalhes(False, 'Header', sHeader);
  Result := Result + GetParametros(False, qry);
  Result := Result + GetDetalhes(False, 'Body', sBody);

  // fechamento da tabela
  if FParamtersCount = 0 then
    Result := Result + '<tr><td style="text-align: center;">None</td><td><pre>None</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak;

  Result := Result + '</table>' + sLineBreak;

  //----------------------------------------------
  // Responses
  Result := Result + '<br><div class="line" style="border-bottom: 1px solid #ddd; height:18px; margin: 5px 0px 5px 0px;"><p><b style="color: red; border: 1px solid #ddd; background-color:#efefef; border-radius: 5px;padding: 4px 4px 2px 4px;">Responses </b></p></div>' + sLineBreak;

  // tabela de respostas
  Result := Result + '<table style="border: 1px solid #c0c0c0; width:100%" cellpadding=0 cellspacing=0>' + sLineBreak;
  Result := Result + '<tr><td style="text-align: center; background-color:#c0c0c0; width: 150px;">Código</td><td style="background-color:#c0c0c0;">Descrição</td><td style="width:10px; background-color:#c0c0c0;">&nbsp;&nbsp;</td></tr>' + sLineBreak;

  if (qry.FieldByName('response_ok_code').AsString <> '') or
     (qry.FieldByName('response_neg_code').AsString <> '') then begin

     if (qry.FieldByName('response_ok_code').AsString <> '') then
       Result := Result + GetResposta(qry.FieldByName('response_ok_code').AsString,
                                      qry.FieldByName('response_ok_type').AsString,
                                      qry.FieldByName('response_ok_text').AsString);

     if (qry.FieldByName('response_neg_code').AsString <> '') then
       Result := Result + GetResposta(qry.FieldByName('response_neg_code').AsString,
                                      qry.FieldByName('response_neg_type').AsString,
                                      qry.FieldByName('response_neg_text').AsString);
  end else
    Result := Result + '<tr><td style="text-align: center;">&nbsp;</td><td><pre>None</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak;

  Result := Result + '</table>' + sLineBreak;
  Result := Result + '                </div> ' + sLineBreak;
  Result := Result + '            </div> ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaHeader(qry: TZQuery): String;
// retorna o header da rota
var
  sRota, sDescricao, sToggle: String;
begin
  sRota := qry.FieldByName('rtgroup').AsString;
  sDescricao := 'Agrupamento de ' + sRota; //qry.FieldByName('description').AsString;
  sToggle := sRota + IntToStr(qry.FieldByName('idep').AsInteger);

  if Length(sDescricao) > 0 then
     sDescricao := '&nbsp;&nbsp;&nbsp;<i class="name" style="font-size:12px;">' + sDescricao + '</i>';

  Result := '' + sLineBreak;
  Result := Result + '            <!-- início da rota: ' + sRota + ' --> ' + sLineBreak;
  Result := Result + '            <div class="card-container"> ' + sLineBreak;
  Result := Result + '             <div class="card-container-title" onclick="toggleVisibility(''ep'+ sToggle +''')"><span id="icon_ep' + sToggle + '" class="toggle-symbol">▼</span>&nbsp;&nbsp;<strong>' + sRota + '</strong>' + sDescricao + '</div> ' + sLineBreak;
  Result := Result + '             <div class="card-container-body" id="ep' + sToggle +'"> ' + sLineBreak;
  Result := Result + '             ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaFooter(qry: TZQuery): String;
// retorna o footer da rota
var
  sRota: String;
begin
  sRota  := qry.FieldByName('rtgroup').AsString;
  Result := '' + sLineBreak;
  Result := Result + '           </div> <!-- card-container-body --> ' + sLineBreak;
  Result := Result + '           </div> <!-- card-container --> ' + sLineBreak;
  Result := Result + '           <!-- fim da rota: ' + sRota + ' --> ' + sLineBreak;
  Result := Result + '            ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaFields(AIdApi, AIdGroup: Integer; ARouteGroup: String): String;
// campos da tabela para uso com o método POST
var
  j: TJSONArray;
  obj: TJSONObject;
  p: TServiceEndpoint;
  s, sToggle, sRequired: string;
  i: integer;
begin
  Result := '';
  p := TServiceEndpoint.Create(AIdApi);
  s := p.GetFieldsFromPost(AIdApi, ARouteGroup);
  p.Free;

  if Trim(s) = '' then Exit;

  sToggle := ARouteGroup + IntToStr(AIdGroup);

  try
    j := TJSONArray(  GetJSON( s ) );

    if (j <> nil) and (j.Count > 0) then begin
      Result := Result + '<!-- descrição dos campos - início -->' + sLineBreak;
      Result := Result + '<div class="card" style="border: 1px solid #6e69ff; background-color: #e0e0ff; margin-bottom: 5px; padding-top: 5px;" onclick="toggleVisibility(''fields-' + sToggle + ''')">' + sLineBreak;
      Result := Result + '<div class="card-header" id="ch_fields-' + sToggle + '" onclick="toggleVisibility(''fields-' + sToggle + ''')" style="font-size:12px; height:20px;">' + sLineBreak;
      Result := Result + '&nbsp;<strong>Fields</strong><i class="name">Descrição dos campos</i>' + sLineBreak;
      Result := Result + '</div>' + sLineBreak;
      Result := Result + ' <div class="card-body" id="fields-' + sToggle + '">' + sLineBreak;
      Result := Result + '  <div class="table-container">' + sLineBreak;
      Result := Result + '    <div class="table-row">' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:200px;">Field Name</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:100px;">Field Type</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:80px;">Max Length</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:80px;">Required</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell">Description</div>' + sLineBreak;
      Result := Result + '    </div>' + sLineBreak;

      for i := 0 to j.Count - 1 do begin
        obj := TJSONObject( j.Objects[i] );
        if obj <> nil then begin
          if obj.Get('field_required', False) then sRequired := 'yes' else sRequired := 'no';
          Result := Result + '    <div class="table-row">' + sLineBreak;
          Result := Result + '        <div class="table-cell" style="max-width:200px;">' + obj.Get('field_name','undefined') + '</div>' + sLineBreak;
          Result := Result + '        <div class="table-cell" style="max-width:100px;">' + obj.Get('field_type','undefined') + '</div>' + sLineBreak;
          Result := Result + '        <div class="table-cell" style="max-width:80px;">' + obj.Get('field_length','0') + '</div>' + sLineBreak;
          Result := Result + '        <div class="table-cell" style="max-width:80px;">' + sRequired + '</div>' + sLineBreak;
          Result := Result + '        <div class="table-cell">' + obj.Get('field_description','undefined') + '</div>' + sLineBreak;
          Result := Result + '    </div>' + sLineBreak;
        end; // if
      end; // for

      Result := Result + '  </div>' + sLineBreak;
      Result := Result + ' </div>' + sLineBreak;
      Result := Result + '</div>' + sLineBreak;
      Result := Result + '<!-- descrição dos campos - fim -->' + sLineBreak;
    end;
  finally
    j.Free;
  end;
end;

function TUtilGeraDoc.GetResposta(ACode, AContentType, AResponse: string): String;
// retorna uma tr com a response
var
  f: array of string;
  codigo, codigotxt: String;
begin
  f := ACode.Split(['-'], TStringSplitOptions.ExcludeEmpty);
  if High(f) <> 1 then Exit('');

  codigo    := f[0];
  codigotxt := f[1];

  Result := '<tr>' +
            '<td style="text-align: center; border-bottom: 1px solid #ddd;">' + codigo + '</td>' +
            '<td style="border-bottom: 1px solid #ddd;">' +
            ' <div class="linha" style="height:12px; margin: 6px 5px 0px 3px;">' +
            '  <p style="font-color:#ccc; font-size:11px;">' + codigotxt + '</p>' +
            '  <p style="font-color:#ccc; font-size:11px;">' + AContentType + '&nbsp;&nbsp;</p>' +
            ' </div>' +
            ' <pre>' + AResponse  +'</pre>' +
            '</td>' +
            '<td style="width:10px;">&nbsp;&nbsp;</td>' +
            '</tr>' + sLineBreak;
end;

function TUtilGeraDoc.GetDetalhes(AOcultar: Boolean; ATitulo, AValor: String): String;
// retorna dados do header e  body
begin
  Result := '<tr>' +
            '<td style="text-align: center; border-bottom: 1px solid #ddd;"><p>' + ATitulo + '</p></td> ' +
            '<td style="border-bottom: 1px solid #ddd;">' +
            //' <div class="linha" style="height:12px; margin: 6px 5px 0px 3px;">' +
            //'  <p style="font-color:#ccc; font-size:11px;">' + '' + '</p>' +
            //'  <p style="font-color:#ccc; font-size:11px;">' + '' + '&nbsp;&nbsp;</p>' +
            //' </div>' +
            ' <pre>' + AValor + '</pre>' +
            '</td>' +
            '<td style="width:10px;">&nbsp;&nbsp;</td>' +
            '</tr>' + sLineBreak;

  if AOcultar and (AValor = 'None') then
    Result := ''
  else
    FParamtersCount := FParamtersCount + 1;
end;

function TUtilGeraDoc.GetParametros(AOcultar: Boolean; qry: TZQuery): String;
// retorna os parâmetros do entpoint
var
  j: TJSONArray;
  obj: TJSONObject;
  s: String;
  i: Integer;
begin
  s := 'None';

  if (Trim(qry.FieldByName('parameters').AsString) <> '') then begin
    try
      j := TJSONArray( GetJSON( qry.FieldByName('parameters').AsString ) );

      if (j <> nil) and (j.Count > 0) then begin
        s := '<table border="0" style="width:100%;">';

        for i :=0 to j.Count -1 do begin
          obj := TJSONObject( j.Objects[i] );
          if obj <> nil then
            s := s +
              '<tr style="background-color: #f1f3f5;">' +
              '<td style="width: 100px;"><div class="param1">' + obj.get('param_name','') + '</div></td>' +
              '<td style="width: 100px;"><div class="param2">' + obj.get('param_type','') + '</div></td>' +
              '<td style="width: 100%;"><div class="param3">' + obj.get('param_description','') + '</div></td>' +
              '</tr>';
        end; // for

        s := s + '</table>';
      end;
    finally
      j.Free;
    end;
  end; // if

  Result := '<tr>' +
            '<td style="text-align: center; border-bottom: 1px solid #ddd;"><p>Parâmetros</p></td> ' +
            '<td style="border-bottom: 1px solid #ddd;">' +
            ' <pre>' + s + '</pre></td>' +
            '<td style="width:10px;">&nbsp;&nbsp;</td>' +
            '</tr>' + sLineBreak;


  if AOcultar then
    Result := ''
  else
    FParamtersCount := FParamtersCount + 1;
 end;

function TUtilGeraDoc.BodyFromFields(AStrJson: string;ABreakLine: Boolean): string;
// retorna dados para Post/Put, do StringGrid Fields para o Body para o request
var
  ar: TJSONArray;
  j, obj: TJSONObject;
  i: Integer;
begin
  Result := 'None';
  if Trim(AStrJson) = '' then Exit;
  if (AStrJson = '{}') or (AStrJson = '[]') then Exit;

  ar := TJSONArray( GetJSON( AStrJson ) );
  obj := TJSONObject.Create;

  try
    if ar <> nil then begin
      for i := 0 to ar.Count - 1 do begin
        j := TJSONObject( ar.Objects[i] );

        if j <> nil then
          case j.Get('field_type', '') of
            'boolean':  obj.Add(j.Get('field_name', ''), True);
            'datetime': obj.Add(j.Get('field_name', ''), Format('%s', [DateToISO8601(now)]));
            'float':    obj.Add(j.Get('field_name', ''), 2.99);
            'integer':  obj.Add(j.Get('field_name', ''), 1);
            'string':   obj.Add(j.Get('field_name', ''), 'abc');
          end;

      end; // for

      if ar.Count > 0 then begin
        if ABreakLine then
          Result := obj.FormatJSON()
        else
          Result := obj.AsJSON;
      end else
        Result := 'None';

    end else
      Result := Trim(AStrJson);
  finally
    obj.Free;
    ar.Free;
  end;
end;

end.


unit Util.JsonFloat;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, fpjson, jsonparser;

type

 { TJSONFloatToNumber }

 TJSONFloatToNumber = class(TJSONFloatNumber)
 protected
   function GetAsString: TJSONStringType; override;
 end;

 procedure JsonFloatNumber;

implementation

procedure JsonFloatNumber;
begin
  SetJSONInstanceType(jitNumberFloat, TJSONFloatToNumber);
end;

{ TJSONFloatToNumber }

function TJSONFloatToNumber.GetAsString: TJSONStringType;
// como usar:  SetJSONInstanceType(jitNumberFloat, TJSONFloat4Number);
var
  F: TJSONFloat;
  fs: TFormatSettings;
begin
  //Result := inherited GetAsString;
  F := GetAsFloat;
  fs := DefaultFormatSettings;
  fs.DecimalSeparator := '.';

  //Result := FormatFloat('0.00###############', F, fs); // format with your preferences
  Result := FormatFloat('0.00##########', F, fs); // format with your preferences
end;

end.

